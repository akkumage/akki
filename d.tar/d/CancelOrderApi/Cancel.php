<?php 

ini_set("display_errors", "on");
ini_set("soap.wsdl_cache_enabled", 0);
ini_set('soap.wsdl_cache_ttl',0);

$wsdl_url="https://www.hgpmart.com/staging/bike-order-cancel-pre-prod.wsdl";


    function testHello(){

        /*$query_data = new stdClass();

        $query_data->Cancel_spcOrder_Input->HeroOrderNumber = NULL;
        $query_data->Cancel_spcOrder_Input->SDOrderNumber = 100002958;*/

        $query_data = array();

        $query_data['Cancel_spcOrder_Input']['HeroOrderNumber'] = NULL;
        $query_data['Cancel_spcOrder_Input']['SDOrderNumber'] = 100002958;;
      
        //print_r($query_data);exit;

        return $query_data;
    } 

    $client = new SoapClient($wsdl_url,array('cache_wsdl' => WSDL_CACHE_NONE));

    $response = $client->Cancel_spcOrder(testHello());

    
    print_r($response);exit;
    echo $client->__getLastRequest();




exit;