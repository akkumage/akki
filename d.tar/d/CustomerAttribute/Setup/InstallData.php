<?php
/**
 * Customer Dynamic Dropdown Attribute
 * Copyright (C) 2019  free
 * 
 * This file is part of OM/CustomerAttribute.
 * 
 * OM/CustomerAttribute is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace OM\CustomerAttribute\Setup;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\Set as AttributeSet;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use OM\Customerb2b\Model\ResourceModel\Customerb2b\  as Parents;
 
/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    
    /**
     * @var CustomerSetupFactory
     */
    protected $customerSetupFactory;
    
    /**
     * @var AttributeSetFactory
     */
    private $attributeSetFactory;
    
    /**
     * @param CustomerSetupFactory $customerSetupFactory
     * @param AttributeSetFactory $attributeSetFactory
     */
    public function __construct(
        CustomerSetupFactory $customerSetupFactory,
        AttributeSetFactory $attributeSetFactory,
        Parents $parents
    ) {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
        $this->parents = $parents;
    }
 
    
    /**
     * {@inheritdoc}
     */

    public function getAllOptions()
    {
        $collection = $this->parents->create();
        foreach ($collection as $parent) {
           //    $this->_options[]=array('title'=>$parent->getAuthor(), 'value'=>$parent->getAuthor());
            $this->_options[]=$parent->getAuthor();
           
        }
        //var_dump($this->_options);die;
       return $this->_options;
    }
    
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {

         /** @var CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        
        /** @var $attributeSet AttributeSet */
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        
        
        $customerSetup->addAttribute(Customer::ENTITY, 'customer_parent', [
            'type' => 'varchar',
            'label' => 'Customer Parent',
            'input' => 'select',
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
            'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
            'required' => true,
            'visible' => true,
            'user_defined' => true,
            'default' => '0',
            'sort_order' => 201,
            'position' => 201,
            'system' => false,
            'adminhtml_only' => 1,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'is_searchable_in_grid' => true,
            'option' =>
					array (
							'values' =>$this->getAllOptions()
            ),
        ]);


        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'customer_parent')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer','adminhtml_checkout','customer_account_create','customer_account_edit'],
        ]);
        
        $attribute->save();
      
          
      
    }
}
