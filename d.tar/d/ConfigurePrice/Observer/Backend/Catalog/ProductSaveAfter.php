<?php
namespace OM\ConfigurePrice\Observer\Backend\Catalog;
class ProductSaveAfter implements \Magento\Framework\Event\ObserverInterface
{
/**
 * Execute observer
 *
 * @param \Magento\Framework\Event\Observer $observer
 * @return void
*/
    public function execute(\Magento\Framework\Event\Observer $observer) {
       

    $product = $observer->getEvent()->getProduct();


    if($product->getId()){
    	
	    	$configId = $product->getId();
	    	echo $typeId = $product->getTypeId();
	    	//exit;

	    	
	    	$objectManager 		= \Magento\Framework\App\ObjectManager::getInstance();
	    	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
	        $conn = $resource->getConnection();

	    	try{
            	
            		if($typeId == 'configurable'){
			            /* configure product */
			            $config = $conn->fetchAll("SELECT * FROM `catalog_product_entity_decimal` WHERE `entity_id` = {$configId} AND `attribute_id` = 75 ");

			             /* child product price */

			             //echo "SELECT min(`value`) as `price`  FROM `catalog_product_entity_decimal` WHERE `entity_id` in(SELECT product_id  FROM `catalog_product_super_link` WHERE `parent_id` = {$configId}) and (`attribute_id` = 75 OR `attribute_id` = 76)";
			            // exit;
			            $simplePrice = $conn->fetchOne("SELECT min(`value`) as `price`  FROM `catalog_product_entity_decimal` WHERE `entity_id` in(SELECT product_id  FROM `catalog_product_super_link` WHERE `parent_id` = {$configId}) and (`attribute_id` = 75 OR `attribute_id` = 76)");
							
							//echo '<pre>';
							//print_R($config);

							//var_dump($simplePrice);
							//exit;
							

			            if(!empty($config)){

			           	    foreach($config as $values){	           	    	
				            	$conn->query("UPDATE `catalog_product_entity_decimal` SET `value` = '{$simplePrice}' WHERE  `store_id` = 0 &&  `value_id` = {$values['value_id']};");
				            }
			        	
			        	}else{
			        		/* insert new row if price not available */
			        		$conn->query("INSERT INTO `catalog_product_entity_decimal` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES (NULL, '75', '0', '{$configId}', '{$simplePrice}');");
			        	}	

		                   
			        }

			   }catch (Exception $e) { }
	    }   
   
    }
}
