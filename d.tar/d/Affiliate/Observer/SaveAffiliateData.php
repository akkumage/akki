<?php
namespace OM\Affiliate\Observer;

class SaveAffiliateData implements \Magento\Framework\Event\ObserverInterface
{

	protected $_dataHelper;
    protected $_objectManager;
    protected $_orderFactory;    
    protected $_checkoutSession;
    protected $_resource;

 	public function __construct(        
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\ObjectManager\ObjectManager $objectManager,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
		\OM\Affiliate\Helper\Data $dataHelper
    ) {
        $this->_objectManager = $objectManager;        
        $this->_storemanager  = $storeManager;
        $this->_orderFactory  = $orderFactory;
        $this->_resource = $resource;
        $this->_checkoutSession = $checkoutSession;        
		$this->_dataHelper = $dataHelper;

    }

	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$module = $this->_dataHelper->getModuleStatus('enable');
		$save_data = 0;
		if($module){
			$orderIds = $observer->getEvent()->getOrderIds();
			if (count($orderIds)) {
	            $orderId = $orderIds[0];
	            $order = $this->_orderFactory->create()->load($orderId);
				try{
					if(isset($_COOKIE['aff_id'])) {
						$aff_id = (int)$_COOKIE['aff_id'];
					}else{
						$aff_id = '';
					}
					if(isset($_COOKIE['p_id'])) {
						$p_id = $_COOKIE['p_id'];
					}else{
						$p_id = '';
					}
					if(isset($_COOKIE['platform'])) {
						$platform = $_COOKIE['platform'];
					}else{
						$platform = '';
					}
					$order->setUserId($aff_id);
					$order->setProductId($p_id);
			        $order->setPlatform($platform);
			        $order->save();
					$allItems = $order->getAllVisibleItems();
					$qty_ordered = 0;
					foreach ($allItems as $item) {

						if(!$save_data && $item->getProduct()->getId() == $p_id){
							$o_price = $item->getOriginalPrice();
							$s_price = $item->getPriceInclTax();
							$qty_ordered = $qty_ordered+(int)$item->getQtyOrdered();
						}
					}
					if($s_price == $o_price){
						$save_data = 1;
					}
					print_r("save data ".$save_data."<br>");
					print_r("o_price ".$o_price."<br>");
					print_r("s_price ".$s_price."<br>");
					print_r("qty_ordered ".$qty_ordered."<br>");
					if($save_data){
				        $order_date = $order->getCreatedAt();
				        $order_id = (int)$order->getId();
				        $connection = $this->_resource->getConnection();
				        $sql = "INSERT INTO `om_affiliate_order` (`order_id`, `customer_id`, `product_id`, `platform`, `order_date`, `order_status`, `p_orig_price`, `p_sale_price`, `qty_ordered`) VALUES ($order_id, $aff_id, $p_id, '".$platform."', '".$order_date."', 0, $o_price, $s_price, $qty_ordered)";
				        $connection->query($sql);
				    }
				} 
				catch (Exception $e) {
					$e->getMessage();
				}
	        }
		}
	}
}