<?php
namespace OM\Affiliate\Observer;

class OrderStateChange implements \Magento\Framework\Event\ObserverInterface
{
	protected $_objectManager;
	protected $_resource;
	protected $_rewardHelper;
	public function __construct(
		\Magento\Framework\ObjectManager\ObjectManager $objectManager,
		\Magento\Framework\App\ResourceConnection $resource,
		\Mageplaza\RewardPoints\Helper\Data $rewardHelper
		)
	{
		$this->_objectManager = $objectManager;
		$this->_resource = $resource;
		$this->_rewardHelper = $rewardHelper;
	}
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$order = $observer->getEvent()->getOrder();
		$connection = $this->_resource->getConnection();
		if($order->getState() == 'complete'){
			$order_id = $order->getId();
			$sql = "SELECT * FROM `om_affiliate_order` WHERE `order_id` = $order_id";
			$result = $connection->fetchAll($sql);
			$customer = $result[0]['customer_id'];
			$s_price = (int)$result[0]['p_sale_price'];
			$qty_ordered = (int)$result[0]['qty_ordered'];
			$received_price = $s_price*$qty_ordered;
			if($received_price > 0 && $received_price < 2500){
				$percentage = 10;
			}
			elseif($received_price > 2501 && $received_price < 5500){
				$percentage = 18;
			}
			elseif($received_price > 5501){
				$percentage = 25;
			}
			else{
				$percentage = 0;
			}
			$id = $result[0]['id'];
			$action = 'earning_order';
			$earning_distribution = round($received_price*$percentage/100);
			$earn_cash = round($earning_distribution*40)/100;
			$pointAmount = round(2*(($earning_distribution*60)/100));
			$this->_rewardHelper->addTransaction($action, $customer, $pointAmount, $order);
			$update_sql = "UPDATE `om_affiliate_order` SET `earn_point` = $pointAmount, `order_status`= 1, `earn_cash` = $earn_cash WHERE `id` = $id";
			$connection->query($update_sql);
		}
	}
}