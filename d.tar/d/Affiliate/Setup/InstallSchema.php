<?php 
namespace OM\Affiliate\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $connection = $installer->getConnection();
        if (version_compare($context->getVersion(), '1.0.0') < 0){

            if($setup->getConnection()->isTableExists('om_total_share') == false){
                $installer->run('create table om_total_share(
                    id int not null auto_increment,
                    customer_id int(20),
                    product_id int(20),
                    platform varchar(100),
                    user_ip varchar(100),
                    share_date datetime,
                    primary key(id)
                )');
            }

            if($setup->getConnection()->isTableExists('om_total_click') == false){
                $installer->run('create table om_total_click(
                    id int not null auto_increment,
                    customer_id int(20),
                    product_id int(20),
                    platform varchar(100),
                    user_ip varchar(100),
                    return_date datetime,
                    primary key(id)
                )');
            }
            if($setup->getConnection()->isTableExists('om_affiliate_order') == false){
                $installer->run('create table om_affiliate_order(
                    id int not null auto_increment,
                    order_id int(20),
                    customer_id int(20),
                    product_id int(20),
                    platform varchar(100),
                    order_date datetime,
                    earn_cash varchar(20),
                    earn_point varchar(20),
                    order_status smallint(6),
                    p_orig_price decimal(10),
                    p_sale_price decimal(10),
                    qty_ordered int(10),
                    primary key(id)
                )');
            }
        }

        if ($connection->tableColumnExists('sales_order', 'user_id') === false) {
            $connection
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'user_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'length' => 255,
                        'comment' => 'Customer Id'
                    ]
                );
            $connection
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'product_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'length' => 255,
                        'comment' => 'Product Id'
                    ]
                );
            $connection
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'platform',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'length' => 255,
                        'comment' => 'Platform'
                    ]
                );
        }
        $installer->endSetup();
    }
}