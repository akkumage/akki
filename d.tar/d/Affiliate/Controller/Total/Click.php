<?php


namespace OM\Affiliate\Controller\Total;

class Click extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;

    protected $_resource;

    private $_remoteAddress;
    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_resource = $resource;
        $this->_remoteAddress = $remoteAddress;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $request = $this->getRequest()->getParams();
        $platform = $request['platform'];
        $aff_id = (int)$request['aff_id'];
        $p_id = $request['p_id'];
        $date = date("Y-m-d");
        $ip = $this->_remoteAddress->getRemoteAddress();
        $connection = $this->_resource->getConnection();
        $sql = "INSERT INTO `om_total_click` (`customer_id`, `product_id`, `platform`, `user_ip`, `return_date`) VALUES ($aff_id, $p_id, '".$platform."', '".$ip."', '".$date."')";
        $connection->query($sql);
    }
}
