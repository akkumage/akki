<?php


namespace OM\Affiliate\Controller\Total;

class Share extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;

    protected $_resource;
    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_resource = $resource;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $request = $this->getRequest()->getParams();
        $platform = $request['platform'];
        $aff_id = $request['aff_id'];
        $p_id = $request['p_id'];
        $date = date("Y-m-d");
        $connection = $this->_resource->getConnection();
        $sql = "INSERT INTO `om_total_share` (`customer_id`, `product_id`, `platform`, `share_date`) VALUES ($aff_id, $p_id, '".$platform."', '".$date."')";
        $connection->query($sql);
        //return $this->resultPageFactory->create();
    }
}
