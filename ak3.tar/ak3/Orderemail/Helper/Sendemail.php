<?php
 
namespace Vajor\Orderemail\Helper;
 
use Magento\Framework\App\Helper\AbstractHelper;
 
class Sendemail extends AbstractHelper
{
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
 
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {
        $this->_request = $request;
        $this->_transportBuilder = $transportBuilder;
        $this->_storeManager = $storeManager;
    }
 
    public function execute($orderIncrementId, $custEmail, $custName)
    {
		if($orderIncrementId){
			$store = $this->_storeManager->getStore()->getId();
			$transport = $this->_transportBuilder->setTemplateIdentifier('orderemail_paymentstatus_template')
				->setTemplateOptions(['area' => 'frontend', 'store' => $store])
				->setTemplateVars(
					[
						'store' => $this->_storeManager->getStore(),
                        'order_id' => $orderIncrementId,
					]
				)
				->setFrom('general')
				// you can config general email address in Store -> Configuration -> General -> Store Email Addresses
				->addTo($custEmail, $custName)
				->getTransport();
			$transport->sendMessage();
			return $this;
		}
    }
}