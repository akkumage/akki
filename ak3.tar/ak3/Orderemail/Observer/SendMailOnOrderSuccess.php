<?php

namespace Vajor\Orderemail\Observer;

use Magento\Framework\Event\ObserverInterface;

class SendMailOnOrderSuccess implements ObserverInterface
{
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderModel;

    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\OrderSender
     */
    protected $orderSender;

    /**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
	
	/**
     * @var \Vajor\Orderemail\Helper\Sendemail
     */
    protected $helper;

    /**
     * @param \Magento\Sales\Model\OrderFactory $orderModel
     * @param \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Vajor\Orderemail\Helper\Sendemail $helper
     *
     * @codeCoverageIgnore
     */
    public function __construct(
        \Magento\Sales\Model\OrderFactory $orderModel,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        \Magento\Checkout\Model\Session $checkoutSession,
		\Vajor\Orderemail\Helper\Sendemail $helper
    )
    {
        $this->orderModel = $orderModel;
        $this->orderSender = $orderSender;
        $this->checkoutSession = $checkoutSession;
        $this->helper = $helper;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$order = $observer->getEvent()->getOrder();
		// Setting success flag
		$order->setSuccessFlag(1);
		$paymentStatus = $observer->getEvent()->getStatus();
		$orderId = $order->getId();
        $orderIncrementId = $order->getIncrementId();
		$custEmail = $order->getCustomerEmail();
		$custName = $order->getCustomerName();
			
        if($orderId)
        {
			if($paymentStatus == 1)
			{
				// Sending Order Confirmation on Success
				$this->orderSender->send($order, true);
			}
			else
			{	
				// Calling helper function to send custom template on payment failed
				$this->helper->execute($orderIncrementId, $custEmail, $custName);
			}
        }
    }
}