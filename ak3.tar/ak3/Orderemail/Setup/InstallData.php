<?php
namespace Vajor\Orderemail\Setup;
 
use Magento\Sales\Setup\SalesSetupFactory;
use Magento\Sales\Model\Order;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
 
class InstallData implements InstallDataInterface
{
 
    protected $salesSetupFactory;
 
    /**
     * @param SalesSetupFactory $salesSetupFactory
     */
    public function __construct(
        SalesSetupFactory $salesSetupFactory
    ) {
        $this->salesSetupFactory = $salesSetupFactory;
    }
 
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
 
        /** @var SalesSetup $salesSetup */
        $salesSetup = $this->salesSetupFactory->create(['setup' => $setup]);
 
        $salesSetup->addAttribute(Order::ENTITY, "two_way_status", [
            'type'     => "varchar",
            'label'    => "TwoWay Status",
            'input'    => "text",
            'user_defined' => true,
        ]);
 
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order_grid'),
            "two_way_status",
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 50,
                'nullable' => true,
                'comment' => "TwoWay Status"
            ]
        );
 
        $setup->endSetup();
 
    }
}