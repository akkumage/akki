<?php

namespace Vajor\Orderemail\Model\Order\Email;

use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Container\IdentityInterface;
use Magento\Sales\Model\Order\Email\Container\Template;
use Magento\Sales\Model\Order\Address\Renderer;

class Sender extends \Magento\Sales\Model\Order\Email\Sender
{
	
    protected function checkAndSend(Order $order)
    {
        // Getting payment code from order
		$payment = $order->getPayment();
		$method = $payment->getMethodInstance();
		$methodCode = $method->getCode();
		
        $this->identityContainer->setStore($order->getStore());
        if (!$this->identityContainer->isEnabled()) {
            return false;
        }else if($order->getSuccessFlag() == 1 || $methodCode == 'msp_cashondelivery'){
			$this->prepareTemplate($order);

			/** @var SenderBuilder $sender */
			$sender = $this->getSender();

			try {
				$sender->send();
				$sender->sendCopyTo();
			} catch (\Exception $e) {
				$this->logger->error($e->getMessage());
			}
		}

        return true;
    }

}
