<?php

$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$request = $objectManager->create('Magento\Framework\App\Request\Http'); 
// getting store url
$storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
$currentStore = $storeManager->getStore();
// getting media url
$storeUrl = $currentStore->getBaseUrl();
$mediaUrl =  $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
$getParams = $request->getParams();

$store_banner = "". $mediaUrl."wysiwyg/stores/storebanner.png";
$storePic = $mediaUrl.'wysiwyg/stores/';


// Pune store

$storeList[0]["name"] = "Pune";
$storeList[0]["title"] = "The Pavillion";
$storeList[0]["email"] = "vajorpune@vajor.com";
$storeList[0]["contact"] = "+91 20 66421196";
$storeList[0]["isOpen"] = true;
$storeList[0]["openDays"] = "Monday - Sunday";
$storeList[0]["openTiming"] = "10AM-8PM";
$storeList[0]["banner"] = $storePic.'pune-banner.jpg';
$storeList[0]["homeImage"] = $storePic.'pune1.jpg';
$storeList[0]["defaultImage"] = $storePic.'pune1.jpg';
$storeList[0]["images"] = "pune_1.jpg, pune_2.jpg, pune_4.jpg, pune_5.jpg, pune_6.jpg";
$storeList[0]["latitude"] = "18.53375";
$storeList[0]["longitude"] = "73.82982";
$storeList[0]["address"] = "The Pavillion,<br/> 
							Ground Floor, <br/>
							Senapati Bapat Road, <br/>
							Shivaji Nagar, <br/>
							Pune - 411016";

$storeList[0]["description"] = "Our very first retail store in Pune welcomes you to a modern bohemian world of Clothing, Accessories & Decor with a lively flavor indigenous to this city... Walk into a world of earthy charm infused with an effortless shopping experience.";



// Channai store
$storeList[1]["name"] = "Chennai";
$storeList[1]["title"] = "Palladium";
$storeList[1]["email"] = "";
$storeList[1]["contact"] = "+91 44 6115 3027";
$storeList[1]["isOpen"] = true;
$storeList[1]["openTiming"] = "10AM-8PM";
$storeList[1]["openDays"] = "Monday - Sunday";
$storeList[1]["banner"] = $storePic.'pune-banner.jpg';
$storeList[1]["homeImage"] = $storePic.'chennai1.jpg';
$storeList[1]["defaultImage"] = $storePic.'chennai1.jpg';
$storeList[1]["images"] = 'chennai_0.jpg, chennai_1.jpg, chennai_2.jpg, chennai_3.jpg, chennai_4.jpg';
$storeList[1]["latitude"] = "12.99295";
$storeList[1]["longitude"] = "80.21784";
$storeList[1]["address"] = "Palladium,<br/> 
							Lower Ground Floor, <br/>
							28, Velachery Road, <br/>
							Nagendra Nagar, Anna Garden, Velachery, <br/>
							Chennai -  600042";

$storeList[1]["description"] = "Bringing its modern bohemian presence to the fresh and green life of Chennai city, Vajor store houses the Clothing, Accessories & Decor that will beautifully interlace with the charming and relaxed vibe of the city.";

// Delhi store

$storeList[2]["name"] = "Delhi";
$storeList[2]["title"] = "Ambience, Vasant Kunj";
$storeList[2]["email"] = "";
$storeList[2]["contact"] = "+91 011 40870531";
$storeList[2]["isOpen"] = true;
$storeList[2]["openTiming"] = "11AM-9:30PM";
$storeList[2]["openDays"] = "Monday - Sunday";
$storeList[2]["banner"] = $storePic.'pune-banner.jpg';
$storeList[2]["homeImage"] = $storePic.'delhi3.jpg';
$storeList[2]["defaultImage"] = $storePic.'delhi3.jpg';
$storeList[2]["images"] = "d1.jpg, d2.jpg, d3.jpg, d4.jpg, d5.jpg, d6.jpg, d7.jpg";
$storeList[2]["latitude"] = "28.5412";
$storeList[2]["longitude"] = "77.15491";
$storeList[2]["address"] = "Ambience Mall Vasant Kunj, <br/>
							Ground Floor, <br />Plot No. 2, <br/>
							Nelson Mandela Marg, <br/>
							Vasant Kunj, New Delhi, <br/>
							Delhi 110070";

$storeList[2]["description"] = "Bringing its modern bohemian presence to the fresh and green life of Delhi city, Vajor store houses the Clothing, Accessories & Decor that will beautifully interlace with the charming and relaxed vibe of the city.";

// Delhi store

$storeList[3]["name"] = "Bengaluru";
$storeList[3]["title"] = "Navajyothi Complex";
$storeList[3]["email"] = "";
$storeList[3]["contact"] = "080-43744910";
$storeList[3]["isOpen"] = true;
$storeList[3]["openTiming"] = "11 AM to 10 PM";
$storeList[3]["openDays"] = "Monday - Sunday";
$storeList[3]["banner"] = $storePic.'ban-banner.jpg';
$storeList[3]["homeImage"] = $storePic.'ban_hm.jpg';
$storeList[3]["defaultImage"] = $storePic.'ban8.jpg';
$storeList[3]["images"] = "ban_1.jpg, ban_2.jpg, ban3.jpg, ban4.jpg, ban5.jpg, ban6.jpg, ban_7.jpg";
$storeList[3]["latitude"] = "12.9773259";
$storeList[3]["longitude"] = "77.6406801";
$storeList[3]["address"] = "Vajor Store, <br /> 
							Navajyothi Complex,<br />
							Plot No. 654,<br />
							10th A Main,<br />
							Binnamangla, 1st Stage, <br />
							Indiranagar, Bengaluru,<br />
							Karnataka - 560038";

$storeList[3]["description"] = "Bengaluru, the city that lives to the fullest and loves to the fullest (especially animals), now has a new address for their fashion & lifestyle needs. Vajor, a modern bohemian brand opens doors to its store that houses effortless and meaningful clothing, accessories and decor. Drop by today and experience the world of Vajor today.";
$listStore = $storeList;




function smallInfoStore($listStore, $storeUrl){
 $storeListHtml= '';
 $storeContent = '';

foreach ($listStore as $key => $store) {
	$activeClass = '';
	$isOpen = ' storeOpen';
	if($key==0){
		$activeClass = 'active';
	}
	if($store['isOpen']==false){
		$isOpen = ' storeComming';
	}
	$storeListHtml .= '<li class="'.$activeClass.$isOpen.'">';
	$storeListHtml .= '<a href="'.$storeUrl.'/vajorstores/?store='.$store['name'].'">';
	$storeListHtml .='<img src="'.$store['homeImage'].'" />
							<div class="storeTag"><strong>'.$store['name'].'  <span style="display:block">'.$store['title'].'</span></strong></div>
						</a>
					</li>';
	$storeContent .='<li class="'.$activeClass.$isOpen.'">
						<h2>
							<i class="storeicon"></i>
							'.$store['name'].' - <span>'.$store['title'].'</span>
						</h2>
						<p>'.$store['description'].'</p>
						<a href="http://maps.google.com/?saddr=My+Location&daddr='.$store['latitude'].','.$store['longitude'].'&travelmode=bike" class="discoverStore" target="_blank">DISCOVER STORE</a>
						<a href="http://www.google.com/maps/place/'.$store['latitude'].','.$store['longitude'].'
" class="fa fa-map-marker" target="_blank"></a>

					</li>';
}
$storeTemplate = '<div class="storeListWrapper">
	<h2>A vajor store is now blossoming in these cities<span>Visit us for a modern bohemian experience now</span></h2>
	<div class="storeList"><ul>'.$storeListHtml.'</ul></div>
	<div class="storeContent"><ul>'.$storeContent.'</ul></div>
</div>';

 return  $storeTemplate;
}

function singleStorePage($listStore,$storeName, $storeUrl, $storePic){
	// Banner
	 $storeBanner = '';
	 $storeLink = '';
	 $title = '';
	 $address = '';
	 $location = '';
	 $storePhotos = '';
	 foreach ($listStore as $key => $store) {
	 	$activeClass = '';
	 	if($store['name']==$storeName){
	 		$activeClass = 'active';
	 		 $storeBanner .= '<div><img data-src="'.$store['banner'].'" /> </div>';

	 		// title 
	 		$title .= '<div class="storeTopTitlebar">
		 		  			<h2>
								<i class="storeicon"></i><br>
									Vajor in '.$store['name'].'</span>
							</h2>
							<div class="storeDes">'.$store['description'].'</div>
						</div>';
			//adress
			 $address .='<div class="addressCol"> 
		 					<h3>'.$store['name'].'</h3>
		 					<p>'.$store['address'].'</p>
		 					<div class="storeContact">'.$store['contact'].'</div>
		 					<div class="storeEmail"><a href="mailto:'.$store['email'].'">'.$store['email'].'</a></div>
		 					<div class="storeGetDirection">
			 					<a href="http://maps.google.com/?saddr=My+Location&daddr='.$store['latitude'].','.$store['longitude'].'&travelmode=bike" class="discoverStore" target="_blank">
			 					<i class="fa fa-map-marker"></i>
			 						Get Directions
			 					</a>
		 					</div>
		 					
		 					<div class="storeopenDays">'.$store['openDays'].'</div>
		 					<div class="storeOpenTiming">'.$store['openTiming'].'</div>
			 			</div>';

			 // location map
			  $location .='<div class="singleLocation">
			  				<input type="hidden" id="lat" value="'.$store['latitude'].'" /> 
			  				<input type="hidden" id="long" value="'.$store['longitude'].'" /> 
			  				<div id="storeMap"></dov>
			  			</div>';

			 
			 
			  $storeImageCheck = $store['images']!=''? $store['images'] :'';
			  if($storeImageCheck!=''){ 
			  	$storeImageArray = explode(',', $store['images']);
				  $pic = '';
				  foreach ($storeImageArray as $key => $value) {
				  	$pic .='<li><img data-src="'.$storePic.'/slider/'.trim($value).'" /></li>';
				  }

				$storePhotos.= '<div class="flexslider carousel">
								  <ul class="slides">'.$pic.'</ul>
								</div>';
			}

	 	}
	  $storeLinkUrl = $storeUrl.'/vajorstores/?store='.$store['name'];
	  //$storeLinkUrl = $store['name']!='Delhi' ? $storeLinkUrl : 'javascript:void(0);'; 
	  $storeLink .= '<li class="'.$activeClass.'"><a href="'. $storeLinkUrl .'">'.$store['name'].'</a></li>';
	 }
	 $storeLinkMenu = '<div class="storeMenu"><ul >'.$storeLink.'</ul></div>';
	 $addressLocation = '<div>'.$address. $location.'</div>';

	return '<div class="storePageWrapper">'.$storeBanner.$storeLinkMenu.$title.$storePhotos.$addressLocation.'</div>'; 
}




 ?>