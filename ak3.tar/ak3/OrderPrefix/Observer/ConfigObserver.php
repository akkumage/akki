<?php

namespace OM\OrderPrefix\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Psr\Log\LoggerInterface as Logger;
use Magento\SalesSequence\Model\ProfileFactory;
use Magento\SalesSequence\Model\MetaFactory;


class ConfigObserver implements ObserverInterface
{
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @param Logger $logger
     */

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    protected $connection;

    protected $request;

    protected $profileFactory;


    public function __construct(
        Logger $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\ResourceConnection $connection,
        \Magento\Framework\App\Request\Http $request,
        ProfileFactory $profileFactory
    ) {
        $this->logger           = $logger;
        $this->scopeConfig      = $scopeConfig;
        $this->connection       = $connection;
        $this->request          = $request;
        $this->profileFactory   = $profileFactory;
        

    }

    public function execute(EventObserver $observer)
    {

        $storeId            = $observer->getStore();   

        if($storeId){        
            
            $prefix             = $this->request->getPostValue();

            $orderPrefix        = !empty($prefix['groups']['general']['fields']['orderid_prefix']['value']) ? $prefix['groups']['general']['fields']['orderid_prefix']['value'] : $storeId;
            $invoicedPrefix     = !empty($prefix['groups']['inviceidprefix']['fields']['inviceid_prefix']['value']) ? $prefix['groups']['inviceidprefix']['fields']['inviceid_prefix']['value']: $storeId;
            $shipmentPrefix     = !empty($prefix['groups']['shipmentidprefix']['fields']['shipment_prefix']['value']) ? $prefix['groups']['shipmentidprefix']['fields']['shipment_prefix']['value']: $storeId;
            $creditmemoPrefix   = !empty($prefix['groups']['creditmemoidprefix']['fields']['creditmemo_prefix']['value']) ? $prefix['groups']['creditmemoidprefix']['fields']['creditmemo_prefix']['value'] : $storeId;
  


            $tableName      = $this->connection->getConnection()->getTableName('sales_sequence_meta');       

            $bind   = ['store_id' => $storeId];
            $select = $this->connection->getConnection()->select()->from(
               $tableName,
               ['*']
            )->where(
                'store_id = :store_id'
            );

            $sequenceMeta   = $this->connection->getConnection()->fetchAll($select, $bind);
            $metaIds        = array_column($sequenceMeta,'meta_id','entity_type');
                  
            /*
            [order] => 9
            [invoice] => 11
            [shipment] => 12
            [creditmemo] => 14
            */

            if(isset($metaIds)){
                if(!empty($metaIds['order']) && !empty($orderPrefix)){    
                    $orderPrefixModel = $this->profileFactory->create()->load($metaIds['order'],'meta_id');
                    if($orderPrefixModel->getId()){     
                        $orderPrefixModel->setPrefix($orderPrefix)->save();
                    }
                }
           
                
                if(!empty($metaIds['invoice']) && !empty($invoicedPrefix)){    
                    $orderPrefixModel = $this->profileFactory->create()->load($metaIds['invoice'],'meta_id'); 
                    if($orderPrefixModel->getId()){  
                        $orderPrefixModel->setPrefix($invoicedPrefix)->save();
                    }
                }
                

                if(!empty($metaIds['shipment']) && !empty($shipmentPrefix)){    
                    $orderPrefixModel = $this->profileFactory->create()->load($metaIds['shipment'],'meta_id'); 
                    if($orderPrefixModel->getId()){  
                        $orderPrefixModel->setPrefix($shipmentPrefix)->save();
                    }
                }

                if(!empty($metaIds['creditmemo']) && !empty($creditmemoPrefix)){  

                    $orderPrefixModel = $this->profileFactory->create()->load($metaIds['creditmemo'],'meta_id');   
                    if($orderPrefixModel->getId()){  
                        $orderPrefixModel->setPrefix($creditmemoPrefix)->save();
                    }
                }
            }

        }
 

    }
}