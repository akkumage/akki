<?php
namespace OM\Pincodes\Model;
class Pincodes extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'om_pincode';

	protected $_cacheTag = 'om_pincode';

	protected $_eventPrefix = 'om_pincode';

	protected function _construct()
	{
		$this->_init('OM\Pincodes\Model\ResourceModel\Pincodes');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}