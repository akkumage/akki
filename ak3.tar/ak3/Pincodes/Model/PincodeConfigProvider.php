<?php
 
namespace OM\Pincodes\Model;
use Magento\Checkout\Model\ConfigProviderInterface;

class PincodeConfigProvider implements ConfigProviderInterface
{
	const XML_MODULE_STATUS_PATH = "pincode/general/enable";
    protected $_scopeConfig;

    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->_scopeConfig = $scopeConfig;
    }

    public function getConfig()
    {

        $config = [];
        $moduleIsEnabled = $this->checkIsModuleEnabled(self::XML_MODULE_STATUS_PATH);
        if($moduleIsEnabled) {
            $config['pincodestatus'] = true;
        } else {
            $config['pincodestatus'] = false;
        }

        return $config;
    }

    public function checkIsModuleEnabled($path)
    {

        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

    }


}