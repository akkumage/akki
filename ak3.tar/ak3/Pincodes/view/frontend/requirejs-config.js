var config = {
    map: {
        '*': {
            	checkoutjs: 'OM_Pincodes/js/pincodes',
            	'Magento_Checkout/js/view/payment/default':'OM_Pincodes/js/view/payment/default',
        	 }
	    }

};
