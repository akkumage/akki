/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'ko',
    'jquery',
    'uiComponent',
    'Magento_Checkout/js/action/place-order',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/payment-service',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/checkout-data-resolver',
    'uiRegistry',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Ui/js/model/messages',
    'uiLayout',
    'Magento_Checkout/js/action/redirect-on-success',
    'Magento_Checkout/js/action/select-shipping-address',
    'mage/storage',
], function (
    ko,
    $,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    quote,
    customer,
    paymentService,
    checkoutData,
    checkoutDataResolver,
    registry,
    additionalValidators,
    Messages,
    layout,
    redirectOnSuccessAction,
    selectShippingAddressAction,
    storage,
) {
    'use strict';

    return Component.extend({
        redirectAfterPlaceOrder: true,
        isPlaceOrderActionAllowed: ko.observable(quote.billingAddress() != null),
        
        isCustomerLoggedIn: customer.isLoggedIn,

        /**
         * After place order callback
         */
        afterPlaceOrder: function () {
            // Override this function and put after place order logic here
            var isLoggedIn = this.isCustomerLoggedIn();
            if(isLoggedIn == false){
                if(this.item.method == 'msp_cashondelivery'){
                    registry.set('otpstatus','');
                    console.log('unset OTP');
                }
            }
        },

        /**
         * Initialize view.
         *
         * @return {exports}
         */
        initialize: function () {
            var billingAddressCode,
                billingAddressData,
                defaultAddressData;
            this._super().initChildren();
            quote.billingAddress.subscribe(function (address) {
                this.isPlaceOrderActionAllowed(address !== null);
            }, this);
            checkoutDataResolver.resolveBillingAddress();
            //alert(this.item.method);
            var isLoggedIn = this.isCustomerLoggedIn();
            if(isLoggedIn == false){
                var paymentmthd = $("input[name='payment[method]']:checked").val();
                if(paymentmthd == 'msp_cashondelivery'){
                    $('#otpblock').show();
                }else{
                    $('#otpblock').hide();
                }
            }
            //*Ends Custom code for OTP*/

            billingAddressCode = 'billingAddress' + this.getCode();
            registry.async('checkoutProvider')(function (checkoutProvider) {
                defaultAddressData = checkoutProvider.get(billingAddressCode);
                if (defaultAddressData === undefined) {
                    // Skip if payment does not have a billing address form
                    return;
                }
                billingAddressData = checkoutData.getBillingAddressFromData();
                if (billingAddressData) {
                    checkoutProvider.set(
                        billingAddressCode,
                        $.extend(true, {}, defaultAddressData, billingAddressData)
                    );
                }
                checkoutProvider.on(billingAddressCode, function (providerBillingAddressData) {
                    checkoutData.setBillingAddressFromData(providerBillingAddressData);
                }, billingAddressCode);
            });
            return this;
        },

        /**
         * Initialize child elements
         *
         * @returns {Component} Chainable.
         */
        initChildren: function () {
            this.messageContainer = new Messages();
            this.createMessagesComponent();
            return this;
        },

        /**
         * Create child message renderer component
         *
         * @returns {Component} Chainable.
         */
        createMessagesComponent: function () {
            var messagesComponent = {
                parent: this.name,
                name: this.name + '.messages',
                displayArea: 'messages',
                component: 'Magento_Ui/js/view/messages',
                config: {
                    messageContainer: this.messageContainer
                }
            };
            layout([messagesComponent]);
            return this;
        },

        /**
         * Place order.
         */
        placeOrder: function (data, event) {
            var self = this;
            if (event) {
                event.preventDefault();
            }
            var ss = registry.get('otpstatus');
            var zipcode = registry.get('postcode');
            var cashondeliveryotp = this.item.method;
            //console.log('sdfsdfsdf');
            //console.log(zipcode);
            //console.log(cashondeliveryotp);
            console.log('customer order placed!!!!');
            if (this.validate() && additionalValidators.validate()) {
                this.isPlaceOrderActionAllowed(false);

                /*!!Start OTP Varification Code!!*/
                var isLoggedIn = this.isCustomerLoggedIn();
                if(isLoggedIn == false){
                    /*Start Gift Card JUGAD by GUDDU BHAIYA*/
                    var giftcardtype = [];
                    var giftitemsData = window.checkoutConfig.quoteItemData;
                    giftitemsData.forEach(function(item) {
                            giftcardtype.push(item.product_type);
                    });
                    var checkgiftcard = '';
                    if($.inArray("amgiftcard", giftcardtype) != -1) {
                        checkgiftcard = true;
                        if ($.inArray('simple', giftcardtype) != -1 || $.inArray('configurable', giftcardtype) != -1) {
                            checkgiftcard = false;
                        }
                    }else{
                            checkgiftcard = false;
                    }
                    /*Ends Gift Card JUGAD by GUDDU BHAIYA*/

                    if(checkgiftcard == false){
                        if((zipcode !='verified') && (cashondeliveryotp == 'msp_cashondelivery')){
                                jQuery('#otpverfydata').html('Zipcode are not valid.');
                                console.log('stop place order OTP not varified.');
                                return false;
                        }
                        if((ss != 'verified') && (cashondeliveryotp == 'msp_cashondelivery')){
                                jQuery('#otpverfydata').html('OTP are not verified');
                                console.log('stop place order OTP not varified.');
                                return false;
                        }
                    }
                }
                    this.getPlaceOrderDeferredObject()
                        .fail(
                            function () {
                                self.isPlaceOrderActionAllowed(true);
                            }
                        ).done(
                            function () {
                                self.afterPlaceOrder();

                                if (self.redirectAfterPlaceOrder) {
                                    redirectOnSuccessAction.execute();
                                }
                            }
                    );
                return true;
            }
            return false;
        },

        /**
         * @return {*}
         */
        getPlaceOrderDeferredObject: function () {
            return $.when(
                placeOrderAction(this.getData(), this.messageContainer)
            );
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);

            /*start Custom code for OTP*/
            var isLoggedIn = this.isCustomerLoggedIn();
            //console.log(isLoggedIn);
            if(isLoggedIn == false){
                if(this.item.method == 'msp_cashondelivery'){
                    $('#otpblock').show();
                }else{
                    $('#otpblock').hide();
                }
            }
            /*Ends Custom code for OTP*/

            return true;
        },

        isChecked: ko.computed(function () {
            return quote.paymentMethod() ? quote.paymentMethod().method : null;
        }),

        isRadioButtonVisible: ko.computed(function () {
            return paymentService.getAvailablePaymentMethods().length !== 1;
        }),

        /**
         * Get payment method data
         */
        getData: function () {
            return {
                'method': this.item.method,
                'po_number': null,
                'additional_data': null
            };
        },

        /**
         * Get payment method type.
         */
        getTitle: function () {
            return this.item.title;
        },

        /**
         * Get payment method code.
         */
        getCode: function () {
            return this.item.method;
        },

        /**
         * @return {Boolean}
         */
        validate: function () {
            return true;
        },

        /**
         * @return {String}
         */
        getBillingAddressFormName: function () {
            return 'billing-address-form-' + this.item.method;
        },

        /**
         * Dispose billing address subscriptions
         */
        disposeSubscriptions: function () {
            // dispose all active subscriptions
            var billingAddressCode = 'billingAddress' + this.getCode();

            registry.async('checkoutProvider')(function (checkoutProvider) {
                checkoutProvider.off(billingAddressCode);
            });
        }
    });
});