define(
    [
        'ko',
        'uiComponent',
        'jquery',
        'jquery/ui',        
        'mage/storage',
        'mage/url',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/action/select-payment-method',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/view/payment/default',
        'uiRegistry',
        'Magento_Customer/js/model/customer'
    ],
    function (ko, Component, $, $$, storage, urlBuilder, fullScreenLoader, selectPaymentMethod, quote, selectotp, registry, customer) {
        "use strict";

        var otpMobile = ko.observable(null);
        var otpNo = ko.observable(null);
        var configValues = window.checkoutConfig;

        return Component.extend({
            isCustomerLoggedIn: customer.isLoggedIn,
            otpMobile: otpMobile,
            otpNo: otpNo,
            defaults: {
                template: 'OM_Pincodes/payment/pincode-otp'
            },

            initialize:function(){
                var self = this;
                this._super();
                var isLoggedIn = this.isCustomerLoggedIn();

                if(isLoggedIn == false){

                $(document).on('keyup', 'input[name=telephone]', function(){
                    var telephone = $('input[name=telephone]').val();
                        self.autoMobile(telephone);
                });
                /**/
                //$(document).on('blur', 'input[name=postcode]', function(){
                    //var zipcode = $('input[name=postcode]').val();
                $(document).on('blur', 'div.field[name="shippingAddress.postcode"] input[name=postcode]', function(){
                    jQuery("input[name=postcode]").removeClass("currentzipcode");
                    jQuery(".custompin").remove();
                    var zipcode = $(this).val();
                    $(this).addClass("currentzipcode");
                    var paymentmethod = $("input[name='payment[method]']:checked").val();
                    if((zipcode.length == 6) && (paymentmethod == 'msp_cashondelivery'))
                    {
                        self.ZipcodeValidation(zipcode);                        
                    }
                });
                $(document).on("change", "input[name='payment[method]']", function(){
                        var zipcode = $('input[name=postcode]').val();
                        var paymentmethod = $("input[name='payment[method]']:checked").val();
                        if((zipcode.length == 6) && (paymentmethod == 'msp_cashondelivery'))
                        {       
                            if(isLoggedIn == false){
                                self.ZipcodeValidation(zipcode);                        
                            }
                        }
                });
                /*shipping Address*/
                $(document).on('keyup', 'div.field[name="billingAddress.telephone"] input[name=telephone]', function(){                
                    var billingmobile = jQuery("div.field[name='billingAddress.telephone'] input[name=telephone]").val();
                    jQuery("#otp-mobile").val(billingmobile);
                    console.log('sdfsdfsdfsd sdfsdf');
                });
            }

            },

            ZipcodeValidation : function(pincodes){
                var pincode = pincodes;
                //console.log(pincode);
                var param = {'postcode':pincode};
                jQuery(".custompin").remove();
                fullScreenLoader.startLoader();
                storage.post(
                    'pincodes/index/index',
                    JSON.stringify(param),
                    false
                ).done(
                    function (response) {
                            jQuery(".custompin").remove();
                            if(response.success == true){
                                jQuery('.currentzipcode').after('<div class="custompin"></div>');
                                jQuery(".custompin").css("color", "green");
                                jQuery('.custompin').html('');
                                //jQuery('.custompin').html('Postcode are valid!');
                                jQuery('.payment-methods .primary').attr("disabled", false);
                                registry.set('postcode','verified');
                                fullScreenLoader.stopLoader();
                            }else if(response.success == false){

                                console.log('data ends here!!!!');
                                jQuery('.currentzipcode').after('<div class="custompin"></div>');
                                jQuery(".custompin").css("color", "red");
                                jQuery('.custompin').html('');
                                jQuery('.custompin').html('Please enter valid Postcode!');
                                //jQuery('.payment-methods .button').attr("disabled", true);
                                jQuery('.payment-methods .primary').attr("disabled", true);
                                registry.set('postcode','unverified');
                                fullScreenLoader.stopLoader();
                            }
                    }
                ).fail(
                    function (response) {
                        jQuery("#message").html(response.msg);
                         fullScreenLoader.stopLoader();
                    }
                );
            },

            autoMobile : function(tel){
                jQuery("#otpsection").hide();
                jQuery('#otp-mobile').prop('disabled', false);
                jQuery('.otp-mobile').prop('disabled', false);
                var tels  = tel;
                var checkbillingmobile = jQuery("div.field[name='billingAddress.telephone'] input[name=telephone]").val();
                if(checkbillingmobile == ""){
                    console.log('sgfshdf');
                    $('#otp-mobile').val(tels);
                }
                return;
            },

            otpApply: function ($) {

            var isLoggedIn = this.isCustomerLoggedIn();

                if(isLoggedIn == false){

                if (!this.validateForm('#otp-form')) {
                     return;
                }
                
                var mobileno = jQuery('#otp-mobile').val();
                //jQuery('#otp-no').val();
                jQuery('#otpsection').hide();
                jQuery('#otpmessage').html(" ");
                var param = {
                    'otp_mobile' : mobileno
                }
                var urls = urlBuilder.build('pincodes/otp/index');
                fullScreenLoader.startLoader();
                storage.post(
                    'pincodes/otp/index',
                    JSON.stringify(param),
                    false
                ).done(
                    function (response) {
                            //console.log(response);
                            if(response.success == 'true'){
                                jQuery('#otpsection').show();
                                jQuery('#resend-otpbtn').show();
                                jQuery('#otp-mobile').prop('disabled', true);
                                jQuery('.otp-mobile').prop('disabled', true);
                                jQuery('#otp-no').prop('disabled', false);
                                jQuery('.checkout-payment-method.submit .payment-methods .actions-toolbar .primary').prop('disabled', true);
                            }
                            jQuery("#message").html(response.msg);
                            fullScreenLoader.stopLoader();
                    }
                ).fail(
                    function (response) {
                        jQuery("#message").html(response.msg);
                        fullScreenLoader.stopLoader();
                    }
                );

                }

            },


            otpResendApply: function ($) {

            var isLoggedIn = this.isCustomerLoggedIn();

                if(isLoggedIn == false){

/*                if (!this.validateForm('#otp-form')) {
                     return;
                }
*/                
                var mobileno = jQuery('#otp-mobile').val();
                var param = {
                    'otp_mobile' : mobileno
                }
                var urls = urlBuilder.build('pincodes/otp/index');
                fullScreenLoader.startLoader();
                storage.post(
                    'pincodes/otp/index',
                    JSON.stringify(param),
                    false
                ).done(
                    function (response) {
                            //console.log(response);
                            if(response.success == 'true'){
                                jQuery('#otpsection').show();
                                jQuery('#resend-otpbtn').show();
                                jQuery('.otp-numbers').prop('disabled', false);
                                jQuery('#otp-no').prop('disabled', false);
                            }
                            jQuery("#message").html(response.msg);
                            fullScreenLoader.stopLoader();
                    }
                ).fail(
                    function (response) {
                        jQuery("#message").html(response.msg);
                        fullScreenLoader.stopLoader();
                    }
                );

                }

            },

            otpVerify: function ($) {

                var isLoggedIn = this.isCustomerLoggedIn();

                if(isLoggedIn == false){

                if (!this.validateForm('#otp-form')) {
                     return;
                }
                var currentmobile =  jQuery("#otp-mobile").val();
                var otp = this.otpNo();
                if(otp.length >= 4){
                    var param = {
                        'otp_no' : otp,
                        'mobile' : currentmobile
                    }
                    fullScreenLoader.startLoader();
                    storage.post(
                        'pincodes/otp/otpverify',
                        JSON.stringify(param),
                        false
                    ).done(
                        function (response) {
                                //console.log(response);
                                //alert('Success');
                                //jQuery('#otpmessage').html(response.status);
                                //console.log(response.status);
                                if(response.status == 'success'){
                                    registry.set('otpstatus','verified');
                                    jQuery('.checkout-payment-method.submit .payment-methods .actions-toolbar .primary').prop('disabled', false);
                                    jQuery('#otp-no').prop('disabled', true);
                                    jQuery('.otp-numbers').prop('disabled', true);
                                }else{
                                    registry.set('otpstatus','unverified');
                                }
                                jQuery('#otpmessage').html(response.msg);
                                fullScreenLoader.stopLoader();
                        }
                    ).fail(
                        function (response) {
                            //console.log(response.status);
                            jQuery('#otpmessage').html(response.msg);
                            jQuery('#otp-no').prop('disabled', false);
                            fullScreenLoader.stopLoader();
                        }
                    );
                }
                }
            },

            /*Not in use otp varification*/

             otpResend: function ($) {
                var mobileno = this.otpMobile();
                //alert('sdfsdf sdfsdf');
                alert(mobileno);
                var param = {
                    'otp_mobile' : mobileno
                }
                fullScreenLoader.startLoader();
                storage.post(
                    'pincodes/otp/otpresend',
                    JSON.stringify(param),
                    false
                ).done(
                    function (response) {
                        //console.log(response);
                        jQuery('#otp-no').prop('disabled', false);
                        console.log('check resend OTP!!!');
                        jQuery('#resendotpmessage').html(response.msg);
                        //alert('Success');
                        fullScreenLoader.stopLoader();
                    }
                ).fail(
                    function (response) {
                        fullScreenLoader.stopLoader();
                    }
                );
            },

            validateForm: function (form) {
                 return $(form).validation() && $(form).validation('isValid');
            },

            checkModuleIsEnable: function () {
                return window.checkoutConfig.pincodestatus;
            },


        });
    },
);