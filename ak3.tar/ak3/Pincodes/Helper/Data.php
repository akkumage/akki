<?php
namespace OM\Pincodes\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

  class Data extends AbstractHelper
  {

      const XML_PATH_PINCODES = 'pincode/';

      protected $_coreSession;

      public function __construct(
            \Magento\Framework\App\Helper\Context $context,
            \Magento\Framework\Session\SessionManagerInterface $coreSession
        ) {

            $this->_coreSession = $coreSession;
            parent::__construct($context);
      }



      public function getConfigValue($field, $storeId = null)
      {
        return $this->scopeConfig->getValue(
          $field, ScopeInterface::SCOPE_STORE, $storeId
        );
      }

      public function getGeneralConfig($code, $storeId = null)
      {
        return $this->getConfigValue(self::XML_PATH_PINCODES .'general/'. $code, $storeId);
      }


      public function getApiUrl($code, $storeId = null)
      {

        return $this->getConfigValue(self::XML_PATH_PINCODES .'general/'. $code, $storeId);

      }


      public function getApiUserId($code, $storeId = null)
      {
        return $this->getConfigValue(self::XML_PATH_PINCODES .'general/'. $code, $storeId);
      }


      public function getApiPassword($code, $storeId = null)
      {
        return $this->getConfigValue(self::XML_PATH_PINCODES .'general/'. $code, $storeId);
      }


      public function setPhoneValue($phone){
          $this->_coreSession->start();
          $this->_coreSession->setPhone($phone);
      }

      public function getPhoneValue(){
        $this->_coreSession->start();
        return $this->_coreSession->getPhone();
      }

      public function unPhoneSetValue(){
          $this->_coreSession->start();
          return $this->_coreSession->unsPhone();
      }


      public function setOtpValue($otp){
          $this->_coreSession->start();
          $this->_coreSession->setOtp($otp);
      }

      public function getOtpValue(){
         $this->_coreSession->start();
        return $this->_coreSession->getOtp();
      }

      public function unOtpSetValue(){
          $this->_coreSession->start();
          return $this->_coreSession->unsOtp();
      }


      public function setOtpVarifyStatus($flag){
          $this->_coreSession->start();
          return $this->_coreSession->setFlag();
      }

      public function getOtpVarifyStatus(){
         $this->_coreSession->start();
        return $this->_coreSession->getFlag();
      }

      public function unOtpVarifyStatus(){
         $this->_coreSession->start();
        return $this->_coreSession->unsFlag();
      }


  public function SendOtp($phonenumber){
  
        $phoneno = $phonenumber;
        $apiurl = $this->getApiUrl('api_url');
        $apiuserid = $this->getApiUserId('userid');
        $apipassword = $this->getApiPassword('password');
        $SenderID = 'VAJORC';

        if(!empty($phoneno)){
          $myValue = mt_rand(1000, 9999);
          $varPhNo        = $phoneno;
          $varMSG         = urlencode("Hey ! ".$myValue." is your one time password (OTP) for your recent  transaction at Vajor.com.");
          $varUserName    = $apiuserid;
          $varPWD         = $apipassword;
          $varSenderID    =   $SenderID;

          $data="username=".$varUserName."&password=".$varPWD."&sender=".$varSenderID."&sendto=".$varPhNo."&message=".$varMSG;
          $url = $apiurl;


          $objURL = curl_init($url);
          curl_setopt($objURL, CURLOPT_RETURNTRANSFER,1);
          curl_setopt($objURL,CURLOPT_POST,1);
          curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);

          $retval = trim(curl_exec($objURL));
          $response = curl_getinfo($objURL, CURLINFO_HTTP_CODE);
          $errors = curl_error($objURL);
          curl_close($objURL);
            
          $message = array();
          $storeotp = array();

        if($response==200) {
                $this->setPhoneValue($phoneno);
                $this->setOtpValue($myValue);
                $this->setOtpVarifyStatus(0);
                $dphone = $this->getPhoneValue();
                $dotp = $this->getOtpValue();
                $message['success'] = 'true';
                $message['msg'] = 'OTP SENT';
                $message['mobile'] = $dphone; 
                //$message['otp'] = $dotp;

          } else {
                $message['success'] = 'false';
                $message['msg'] = 'There is some error.';
          }

        }else{
                $message['success'] = 'false';
                $message['msg'] = 'There is some error!';
       }
          //return json_encode($message);
        return $message;


    }
    public function OtpVerify($otpno,$mobile)
    {
        $message = array();
        $otp = $otpno;

        $usermobile  = $mobile;

        if (empty($otp)) {
            $message = "Invalid Value";
        }

        $enteropt = $otpno;
        $OtpCode  = $this->getOtpValue();
        $sessionmobile = $this->getPhoneValue();


        if (($OtpCode == $enteropt) && ($usermobile == $sessionmobile)) {
              $this->setOtpVarifyStatus(1);
              //echo $verifystatus = $this->getOtpVarifyStatus();
              $status = "OK";
              $message['status'] = 'success';
              $message['msg'] = 'OTP is verified!';
              $this->unPhoneSetValue();
              $this->unOtpSetValue();

        } else {
            $this->unOtpVarifyStatus();
            $status = "Error";
            $message['status'] = 'error';
            $message['msg'] = 'OTP are Invalid!';


        }

        return $message;

    }



    public function OtpResend($resendotp){
            $post = $resendotp;
            if (empty($post)) {
                $msg = "Invalid Value";
            }

            $OtpVerifyStatus = $this->getOtpVarifyStatus();
            if ($OtpVerifyStatus != 1) {
                  
                  $this->unOtpVarifyStatus();
                  $this->unOtpSetValue();
                  $this->unPhoneSetValue();
                  
                  /*echo json_encode(array(
                    'status' => 'OK',
                    'message' => 'there is some error'
                  ));*/

            }

    }



  }
