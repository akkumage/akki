<?php
namespace OM\Pincodes\Setup;
class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
	public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
	{
		$installer = $setup;
		$installer->startSetup();
		if (!$installer->tableExists('om_pincode')) {
			$table = $installer->getConnection()->newTable(
				$installer->getTable('om_pincode')
			)
				->addColumn(
					'id',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					null,
					[
						'identity' => true,
						'nullable' => false,
						'primary'  => true,
						'unsigned' => true,
					],
					'ID'
				)
				->addColumn(
				    'pincode',
				    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				    55,
				    ['nullable' => false, 'default' => '0'],
				    'Pincode'
				)
				->setComment('Pincode Table');
			$installer->getConnection()->createTable($table);
			$installer->getConnection()->addIndex(
				$installer->getTable('om_pincode'),
				$setup->getIdxName(
					$installer->getTable('om_pincode'),
					['pincode'],
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
				),
				['pincode'],
				\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
			);
		}
		$installer->endSetup();
	}
}