<?php
namespace OM\Pincodes\Controller\Index;
class Index extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;

    protected $helperData;
    

    protected $helper;


   public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Json\Helper\Data $helper,
        \Magento\Framework\Controller\Result\JsonFactory $resultPageFactory,
        \OM\Pincodes\Helper\Data $helperData
    ) {
        parent::__construct($context);
        $this->helper = $helper;
        $this->helperData = $helperData;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {   

            
        if($this->getRequest()->isAjax()){

            //echo 'sdfsdf sdfsd';
            //echo $pincode = $this->getRequest()->getParam('postcode');
            
            $pincode = $this->helper->jsonDecode($this->getRequest()->getContent());
        
            //$pincodes = $pincode['postcode'];

            //echo 'sdfsdf sdfsf';
            //print_r($pincodes['postcode']);
            //exit;

           // $contactModel = $this->_objectManager->create('OM\Pincodes\Model\Pincodes');
            //$collection = $contactModel->getCollection();
            //$collection = $collection->addFieldToFilter('pincode', array('eq' => $pincodes));
           

            //if($collection->getData()){
                $message['success'] = true;
                $message['pincode'] = $pincode;
                $message['msg'] = 'Pincode exits.';
            //}/*else{
                //$message['success'] =  false;
               // $message['pincode'] =  $pincode;
                //$message['msg'] = 'Pincode does not exits.';
            //}
            $resultJson = $this->resultPageFactory->create();
            return $resultJson->setData($message);

        }
        return false;
    }




}