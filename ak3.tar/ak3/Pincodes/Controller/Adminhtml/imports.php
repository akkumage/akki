<?php

namespace OM\Pincodes\Controller\Adminhtml;
abstract class Imports extends \Magento\Backend\App\Action
{

    public function execute()
    {
        
        echo __('admin controllers Team.');
        die;


    }


}
