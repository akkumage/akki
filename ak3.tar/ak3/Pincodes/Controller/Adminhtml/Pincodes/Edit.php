<?php

namespace OM\Pincodes\Controller\Adminhtml\Pincodes;
class Edit extends \OM\Pincodes\Controller\Adminhtml\Pincodes
{

    private $resultPageFactory;
    private $pincodeModel;
    private $coreRegistry;

     public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \OM\Pincodes\Model\Pincodes $pincodeModel
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->pincodeModel = $pincodeModel;
        $this->coreRegistry = $coreRegistry;
        parent::__construct($context, $coreRegistry);
    }


    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->pincodeModel;
        
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This Pincodes no longer exists.'));
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }

        $this->coreRegistry->register('om_pincodes_pincodes', $model);
        
        $resultPage = $this->resultPageFactory->create();
        $this->initPage($resultPage)->addBreadcrumb(
            $id ? __('Edit Pincode') : __('New Pincode'),
            $id ? __('Edit Pincode') : __('New Pincode')
        );
        
        $resultPage->getConfig()->getTitle()->prepend(__('Pincodes'));
        $resultPage->getConfig()->getTitle()->prepend($model->getId() ? $model->getTitle() : __('New Pincode'));
        
        return $resultPage;
    }
}
