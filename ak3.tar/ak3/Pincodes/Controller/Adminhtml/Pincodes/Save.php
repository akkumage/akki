<?php

namespace OM\Pincodes\Controller\Adminhtml\Pincodes;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{

    private $dataPersistor;

    private $faqModel;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \OM\Pincodes\Model\Pincodes $pincodeModel
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->pincodeModel = $pincodeModel;
        parent::__construct($context);
    }

    public function execute()
    {


        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if ($data) {
            $id = $this->getRequest()->getParam('id');
            $model = $this->pincodeModel->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Pincode no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
        
            $model->setData($data);
        
            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the Pincode.'));
                $this->dataPersistor->clear('om_pincodes_pincodes');
        
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Pincode.'));
            }
        
            $this->dataPersistor->set('om_pincodes_pincodes', $data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function getGroups($groups)
    {
        $groups = implode(',', $groups);
        return $groups;
    }
}
