<?php


namespace OM\Pincodes\Controller\Adminhtml\Pincodes;

class Delete extends \OM\Pincodes\Controller\Adminhtml\Pincodes
{

    public function execute()
    {

        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {

                $model = $this->_objectManager->create('OM\Pincodes\Model\Pincodes');
                $model->load($id);
                $model->delete();

                $this->messageManager->addSuccessMessage(__('You deleted the Pincode.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a Pincode to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}