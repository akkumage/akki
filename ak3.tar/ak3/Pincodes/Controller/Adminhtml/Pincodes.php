<?php

namespace OM\Pincodes\Controller\Adminhtml;
abstract class Pincodes extends \Magento\Backend\App\Action
{
   

    const ADMIN_RESOURCE = 'OM_Pincodes::top_level';
    private $coreRegistry;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry
    ) {
        $this->coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    public function initPage($resultPage)
    {
        $resultPage->setActiveMenu(self::ADMIN_RESOURCE)
            ->addBreadcrumb(__('OM'), __('OM'))
            ->addBreadcrumb(__('Pincodes'), __('Pincodes'));
        return $resultPage;
    }
}
