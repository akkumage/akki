<?php
namespace OM\Pincodes\Controller\Otp;
class Otpverify extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;

    protected $helperData;

    protected $helper;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Json\Helper\Data $helper,
        \Magento\Framework\Controller\Result\JsonFactory $resultPageFactory,
        \OM\Pincodes\Helper\Data $helperData
    ) {
        parent::__construct($context);
        $this->helper = $helper;
        $this->helperData = $helperData;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        if($this->getRequest()->isAjax()){            
            $otp = $this->helper->jsonDecode($this->getRequest()->getContent());
            $otpno = $otp['otp_no'];
            $mobileno = $otp['mobile'];
            $message = $this->helperData->OtpVerify($otpno, $mobileno);
            $resultJson = $this->resultPageFactory->create();
            return $resultJson->setData($message);
        }
        return false;
    }

}