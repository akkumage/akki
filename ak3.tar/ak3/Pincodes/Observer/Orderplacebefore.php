<?php 

namespace OM\Pincodes\Observer;

use Magento\Framework\Event\ObserverInterface;
class Orderplacebefore implements ObserverInterface
{

	public function execute(\Magento\Framework\Event\Observer $observer){
		
	}


}
