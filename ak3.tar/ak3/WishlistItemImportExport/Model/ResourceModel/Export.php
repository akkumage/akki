<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\WishlistItemImportExport\Model\ResourceModel;

use Magento\Framework\App\ResourceConnection;

class Export
{
    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $readAdapter;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var array
     */
    protected $tableNames = [];

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $timezone;

    /**
     * @var \Magento\Wishlist\Model\ItemFactory
     */
    protected $wishlistItemFactory;

    /**
     * @var \Magento\Wishlist\Model\Item\OptionFactory
     */
    protected $itemOption;

    /**
     * @var \Magento\Wishlist\Controller\WishlistProviderInterface
     */
    protected $wishlistProvider;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * Export constructor.
     * @param ResourceConnection $resourceConnection
     * @param \Magento\Store\Api\StoreRepositoryInterface $storeRepository
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Wishlist\Model\ItemFactory $wishlistItemFactory
     * @param \Magento\Wishlist\Model\Item\OptionFactory $itemOption
     * @param \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider
     * @param \Magento\Framework\App\ProductMetadataInterface $productMetadata
     * @param \Magento\Framework\Module\Manager $moduleManager
     */
    public function __construct(
        ResourceConnection $resourceConnection,
        \Magento\Store\Api\StoreRepositoryInterface $storeRepository,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Wishlist\Model\ItemFactory $wishlistItemFactory,
        \Magento\Wishlist\Model\Item\OptionFactory $itemOption,
        \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Magento\Framework\Module\Manager $moduleManager
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->timezone = $timezone;
        $this->readAdapter = $this->resourceConnection->getConnection('core_read');
        $this->wishlistItemFactory = $wishlistItemFactory;
        $this->itemOption = $itemOption;
        $this->wishlistProvider = $wishlistProvider;
        $this->productMetadata = $productMetadata;
        $this->moduleManager = $moduleManager;
    }

    /**
     * @param array $requestData
     * @return \Zend_Db_Statement_Interface
     */
    public function getWishlistItems($requestData)
    {
        $wishlistItemColumns = ['product_id', 'store_id', 'qty', 'added_at', 'description'];
        if ($this->moduleManager->isEnabled('Bss_MultiWishlist')) {
            $wishlistItemColumns = ['product_id', 'store_id', 'qty', 'added_at', 'description', 'multi_wishlist_id'];
        }

        $wishlistColumns = ['wishlist_id', 'customer_id'];
        if ($this->productMetadata->getEdition() == "Enterprise") {
            $wishlistColumns = ['wishlist_id', 'customer_id', 'name'];
        }

        $select = $this->readAdapter->select()
            ->from(
                ['main_table' => $this->getTableName('wishlist')],
                $wishlistColumns
            )->join(
                ['item' => $this->getTableName('wishlist_item')],
                'main_table.wishlist_id = item.wishlist_id',
                $wishlistItemColumns
            )
            ->join(
                ['option' => $this->getTableName('wishlist_item_option')],
                'item.wishlist_item_id = option.wishlist_item_id',
                ['wishlist_item_id', 'code', 'value', 'option_id']
            )->join(
                ['customer' => $this->getTableName('customer_entity')],
                'customer.entity_id = main_table.customer_id',
                ['email', 'group_id']
            )->join(
                ['product' => $this->getTableName('catalog_product_entity')],
                'product.entity_id = item.product_id',
                ['sku', 'type_id']
            )->join(
                ['store' => $this->getTableName('store')],
                'store.store_id = item.store_id',
                ['code']
            )
            ->order(['customer.email'])->group(['item.wishlist_item_id']);

        switch ($requestData['export-by']) {
            case 'customer-email':
                $select->where(
                    "customer.email = :email"
                );
                $bind = [
                    ':email' => $requestData['customer-email']
                ];
                $wishlist = $this->readAdapter->query($select, $bind);
                break;
            case 'product-sku':
                $select->where(
                    "product.sku = :sku"
                );
                $bind = [
                    ':sku' => $requestData['product-sku']
                ];
                $wishlist = $this->readAdapter->query($select, $bind);
                break;
            case 'customer-group':
                $select->where(
                    "customer.group_id = :group_id"
                );
                $bind = [
                    ':group_id' => $requestData['customer-group']
                ];
                $wishlist = $this->readAdapter->query($select, $bind);
                break;
            default:
                $wishlist = $this->readAdapter->query($select);
        }

        return $wishlist;
    }

    /**
     * @param string $entity
     * @return bool|mixed
     */
    protected function getTableName($entity)
    {
        if (!isset($this->tableNames[$entity])) {
            try {
                $this->tableNames[$entity] = $this->resourceConnection->getTableName($entity);
            } catch (\Exception $e) {
                return false;
            }
        }
        return $this->tableNames[$entity];
    }

    /**
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @return string
     */
    public function formatDate($dateTime)
    {
        $dateTimeAsTimeZone = $this->timezone
            ->date($dateTime)
            ->format('YmdHis');
        return $dateTimeAsTimeZone;
    }

    /**
     * @param \Zend_Db_Statement_Interface $wishlistItems
     * @return array
     */
    public function getExportData($wishlistItems)
    {
        $data[0] = [
            'store_code',
            'added_at',
            'user_email',
            'description',
            'product_sku',
            'product_qty',
            'configurable_product_info',
            'grouped_product_info',
            'bundle_product_info',
            'wishlist_name'
        ];

        foreach ($wishlistItems as $wishlistItem) {
            $row=null;

            $item = $this->wishlistItemFactory->create()->loadWithOptions($wishlistItem['wishlist_item_id']);
            $buyRequest = $item->getBuyRequest();

            $row[0] = $wishlistItem['code'];
            $row[1] = $wishlistItem['added_at'];
            $row[2] = $wishlistItem['email'];
            $row[3] = $wishlistItem['description'];
            $row[4] = $wishlistItem['sku'];
            $row[5] = $wishlistItem['qty'];
            switch ($wishlistItem['type_id']) {
                case 'configurable':
                    $row[6] = $this->getConfigurableInfo($buyRequest['super_attribute']);
                    $row[7] = '';
                    $row[8] = '';
                    break;
                case 'grouped':
                    $row[6] = '';
                    $row[7] = $this->getGroupedInfo($buyRequest['super_group']);
                    $row[8] = '';
                    break;
                case 'bundle':
                    $row[6] = '';
                    $row[7] = '';
                    $row[8] = $this->getBundleInfo($buyRequest['bundle_option'], $buyRequest['bundle_option_qty']);
                    break;
                default:
                    $row[6] = '';
                    $row[7] = '';
                    $row[8] = '';
            }
            $row[9] = '';
            if ($this->moduleManager->isEnabled('Bss_MultiWishlist')) {
                $row[9] = $this->getWishlistName($wishlistItem['multi_wishlist_id']);
            }

            if ($this->productMetadata->getEdition() == "Enterprise") {
                $row[9] = $wishlistItem['name'];
            }

            $data[]=$row;
        }
        return $data;
    }

    /**
     * @param int $multiWishlistId
     * @return string
     */
    protected function getWishlistName($multiWishlistId)
    {
        if ($multiWishlistId == 0) {
            return '';
        }
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('bss_multiwishlist')],
            ['wishlist_name']
        )->where(
            'main_table.multi_wishlist_id = :multi_wishlist_id'
        );
        $bind = [
            ':multi_wishlist_id' => $multiWishlistId
        ];
        return $this->readAdapter->fetchOne($select, $bind);
    }

    /**
     * @param array $superAttribute
     * @return string
     */
    protected function getConfigurableInfo($superAttribute)
    {
        $configurableInfo = "";
        if (is_array($superAttribute) || is_object($superAttribute)) {
            foreach ($superAttribute as $attributeId => $optionId) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('eav_attribute')],
                    ['attribute_code', 'attribute_id']
                )->join(
                    ['attribute_option' => $this->getTableName('eav_attribute_option')],
                    'main_table.attribute_id = attribute_option.attribute_id',
                    ['option_id']
                )->join(
                    ['option_value' => $this->getTableName('eav_attribute_option_value')],
                    'attribute_option.option_id = option_value.option_id',
                    ['value']
                )->where("main_table.attribute_id = :attributeId"
                )->where("attribute_option.option_id = :optionId");
                $bind = [
                    ':attributeId' => $attributeId,
                    ':optionId' => $optionId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $configurableInfo .= $result['attribute_code'] . ":" . $result['value'] . "|";
            }
        }
        return rtrim($configurableInfo, "|");
    }

    /**
     * @param array $superGroup
     * @return string
     */
    protected function getGroupedInfo($superGroup)
    {
        $configurableInfo = "";
        if (is_array($superGroup) || is_object($superGroup)) {
            foreach ($superGroup as $childProductId => $qty) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('catalog_product_entity')],
                    ['sku']
                )->where("main_table.entity_id = :entityId");
                $bind = [
                    ':entityId' => $childProductId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $configurableInfo .= $result['sku'] . ":" . $qty . "|";
            }
        }
        return rtrim($configurableInfo, "|");
    }

    /**
     * @param array $bundleOption
     * @param array $bundleOptionQty
     * @return string
     */
    protected function getBundleInfo($bundleOption, $bundleOptionQty)
    {
        $bundleInfo = "";
        if (is_array($bundleOption) || is_object($bundleOption)) {
            foreach ($bundleOption as $bundleItemId => $itemId) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('catalog_product_entity')],
                    ['sku']
                )->join(
                    ['bundle_selection' => $this->getTableName('catalog_product_bundle_selection')],
                    'main_table.entity_id = bundle_selection.product_id',
                    ['selection_id']
                )->where("bundle_selection.selection_id = :selectionId");
                $bind = [
                    ':selectionId' => $itemId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $bundleInfo .= $result['sku'] . ":" . $bundleOptionQty[$bundleItemId] . "|";
            }
        }
        return rtrim($bundleInfo, "|");
    }
}
