<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\WishlistItemImportExport\Model\ResourceModel;

class Import
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    /**
     * @var array
     */
    protected $tableNames = [];

    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $readAdapter;

    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $writeAdapter;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var array
     */
    protected $customers = [];

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;

    /**
     * @var \Magento\Bundle\Model\ResourceModel\Selection
     */
    protected $bundleSelection;

    /**
     * @var array
     */
    protected $storeCodes = [];

    /**
     * @var \Magento\Wishlist\Model\ResourceModel\ItemFactory
     */
    protected $wishlistItemResource;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * Import constructor.
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Bundle\Model\ResourceModel\Selection $selection
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Wishlist\Model\ResourceModel\ItemFactory $wishlistItemResource
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Bundle\Model\ResourceModel\Selection $selection,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Wishlist\Model\ResourceModel\ItemFactory $wishlistItemResource
    ) {
        $this->resource = $resource;
        $this->readAdapter = $this->resource->getConnection('core_read');
        $this->writeAdapter = $this->resource->getConnection('core_write');
        $this->request = $request;
        $this->productFactory = $productFactory;
        $this->bundleSelection = $selection;
        $this->moduleManager = $moduleManager;
        $this->wishlistItemResource = $wishlistItemResource;
    }

    /**
     * @param string $entity
     * @return bool|mixed
     */
    protected function getTableName($entity)
    {
        if (!isset($this->tableNames[$entity])) {
            try {
                $this->tableNames[$entity] = $this->resource->getTableName($entity);
            } catch (\Exception $e) {
                return false;
            }
        }
        return $this->tableNames[$entity];
    }

    /**
     * @return array|bool
     */
    protected function getExistCustomers()
    {
        if (empty($this->customers)) {
            try {
                $select = $this->readAdapter->select()
                    ->from(
                        [$this->getTableName('customer_entity')],
                        ['entity_id', 'email']
                    );

                $result = $this->readAdapter->query($select);
                foreach ($result as $value) {
                    $this->customers[] = $value;
                }
            } catch (\Exception $e) {
                return false;
            }
        }
        return $this->customers;
    }

    /**
     * @param string $userEmail
     * @return null|string
     */
    public function getExistCustomerId($userEmail)
    {
        $customers = $this->getExistCustomers();
        foreach ($customers as $customer) {
            if ($userEmail == $customer['email']) {
                return $customer['entity_id'];
            }
        }
        return null;
    }

    /**
     * @param string $configurableInfo
     * @param string $separator
     * @return array
     */
    public function getConfigurableInfo($configurableInfo, $separator)
    {
        $superAttributes = [];
        if ($configurableInfo != '') {
            $info = explode($separator, $configurableInfo);
            $select = $select = $this->readAdapter->select()->from(
                ['main_table' => $this->getTableName('eav_attribute_option_value')],
                ['option_id']
            )->join(
                ['attribute_option' => $this->getTableName('eav_attribute_option')],
                'main_table.option_id = attribute_option.option_id',
                ['attribute_id']
            );
            $bind = [];
            for ($i = 0; $i < count($info); $i++) {
                $attributeValue = explode(':', $info[$i]);
                if (isset($attributeValue[1])) {
                    $param = 'attribute' . $i;
                    if ($i == 0) {
                        $select->where("main_table.value = :$param");
                    } else {
                        $select->orWhere("main_table.value = :$param");
                    }
                    $bind[":$param"] = $attributeValue[1];
                }
            }
            $result = $this->readAdapter->query($select, $bind);
            foreach ($result as $value) {
                $superAttributes[$value['attribute_id']] = $value['option_id'];
            }
        }

        return $superAttributes;
    }

    /**
     * @param string $groupInfo
     * @param string $separator
     * @return array
     */
    public function getGroupInfo($groupInfo, $separator)
    {
        $superGroup = [];
        if ($groupInfo != '') {
            $childProducts = explode($separator, $groupInfo);
            foreach ($childProducts as $childProduct) {
                $childInfo = explode(':', $childProduct);
                $id = $this->getProductIdBySku($childInfo[0]);
                $qty = $this->getQty($childInfo[1]);
                if (!empty($id)) {
                    $superGroup[$id] = $qty;
                }
            }
        }
        return $superGroup;
    }

    /**
     * @param string $bundleInfo
     * @param string $separator
     * @param string $parentId
     * @return array
     */
    public function getBundleOption($bundleInfo, $separator, $parentId)
    {
        $bundleOption = [];
        if ($bundleInfo != '') {
            $childrenIds = $this->bundleSelection->getChildrenIds($parentId, false);
            $bundleItems = explode($separator, $bundleInfo);
            foreach ($bundleItems as $bundleItem) {
                $itemInfo = explode(':', $bundleItem);
                $id = $this->getProductIdBySku($itemInfo[0]);
                foreach ($childrenIds as $childIds) {
                    if (in_array($id, $childIds)) {
                        $select = $select = $this->readAdapter->select()->from(
                            ['main_table' => $this->getTableName('catalog_product_bundle_selection')],
                            ['selection_id', 'option_id']
                        )->where(
                            'main_table.product_id = :product_id'
                        );
                        $bind = [
                            ':product_id' => $id,
                        ];
                        $selection = $this->readAdapter->fetchRow($select, $bind);
                        $optionId = $selection['option_id'];
                        $bundleOption[$optionId] = $selection['selection_id'];
                    }
                }
            }
        }
        return $bundleOption;
    }

    /**
     * @param string $bundleInfo
     * @param string $separator
     * @param string $parentId
     * @return array
     */
    public function getBundleQty($bundleInfo, $separator, $parentId)
    {
        $bundleQty = [];
        if ($bundleInfo != '') {
            $childrenIds = $this->bundleSelection->getChildrenIds($parentId, false);
            $bundleItems = explode($separator, $bundleInfo);
            foreach ($bundleItems as $bundleItem) {
                $itemInfo = explode(':', $bundleItem);
                $id = $this->getProductIdBySku($itemInfo[0]);
                foreach ($childrenIds as $childIds) {
                    if (in_array($id, $childIds)) {
                        $select = $select = $this->readAdapter->select()->from(
                            ['main_table' => $this->getTableName('catalog_product_bundle_selection')],
                            ['option_id']
                        )->where(
                            'main_table.product_id = :product_id'
                        );
                        $bind = [
                            ':product_id' => $id,
                        ];
                        $optionId = $this->readAdapter->fetchOne($select, $bind);
                        $bundleQty[$optionId] = $this->getQty($itemInfo[1]);
                    }
                    continue;
                }
            }
        }
        return $bundleQty;
    }

    /**
     * @param array $rowData
     * @return array
     */
    public function getWishlistItem($rowData)
    {
        $productId = $this->getProductIdBySku($rowData['product_sku']);
        $customerId = $this->getExistCustomerId($rowData['user_email']);
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('wishlist')],
            ['wishlist_id']
        )->join(
            ['item' => $this->getTableName('wishlist_item')],
            'main_table.wishlist_id = item.wishlist_id',
            ['wishlist_item_id']
        )->where(
            'main_table.customer_id = :customerId'
        )->where(
            'item.product_id = :productId'
        );
        $bind = [
            ':productId' => $productId,
            ':customerId' => $customerId,
        ];
        if ($this->moduleManager->isEnabled('Bss_MultiWishlist')) {
            $select->where('item.multi_wishlist_id = :multi_wishlist_id');
            $bind[':multi_wishlist_id'] = $this->getMultiWishlistId($rowData['wishlist_name'], $customerId);
        }
        return $this->readAdapter->fetchRow($select, $bind);
    }

    /**
     * @param array $rowData
     * @return \Zend_Db_Statement_Interface
     */
    public function getSpecialWishlistItems($rowData)
    {
        $productId = $this->getProductIdBySku($rowData['product_sku']);
        $customerId = $this->getExistCustomerId($rowData['user_email']);
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('wishlist')],
            ['wishlist_id']
        )->join(
            ['item' => $this->getTableName('wishlist_item')],
            'main_table.wishlist_id = item.wishlist_id',
            ['wishlist_item_id']
        )->where(
            'main_table.customer_id = :customerId'
        )->where(
            'item.product_id = :productId'
        );
        $bind = [
            ':productId' => $productId,
            ':customerId' => $customerId,
        ];
        if ($this->moduleManager->isEnabled('Bss_MultiWishlist')) {
            $select->where('item.multi_wishlist_id = :multi_wishlist_id');
            $bind[':multi_wishlist_id'] = $this->getMultiWishlistId($rowData['wishlist_name'], $customerId);
        }
        return $this->readAdapter->query($select, $bind);
    }

    /**
     * @param string $wishlistName
     * @param int $customerId
     * @return string
     */
    protected function getMultiWishlistId($wishlistName, $customerId)
    {
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('bss_multiwishlist')],
            ['multi_wishlist_id']
        )->where(
            'main_table.wishlist_name = :wishlist_name'
        )->where(
            'main_table.customer_id = :customer_id'
        );
        $bind = [
            ':wishlist_name' => $wishlistName,
            ':customer_id' => $customerId
        ];
        return $this->readAdapter->fetchOne($select, $bind);
    }

    /**
     * @param int $wishlistItemId
     * @return string
     */
    public function getBuyRequestInfo($wishlistItemId)
    {
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('wishlist_item_option')],
            ['code']
        )->where(
            'main_table.wishlist_item_id = :wishlist_item_id'
        )->where(
            'main_table.wishlist_item_id = :wishlist_item_id'
        );
        $bind = [
            ':wishlist_item_id' => $wishlistItemId
        ];
        return $this->readAdapter->fetchOne($select, $bind);
    }

    /**
     * @param string $wishlistName
     * @param int $customerId
     * @return string
     */
    public function checkExistedWishlistName($wishlistName, $customerId)
    {
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('bss_multiwishlist')],
            ['multi_wishlist_id']
        )->where(
            'main_table.customer_id = :customer_id'
        )->where(
            'main_table.wishlist_name = :wishlist_name'
        );
        $bind = [
            ':customer_id' => $customerId,
            ':wishlist_name' => $wishlistName
        ];
        $multiWishlistId = $this->readAdapter->fetchOne($select, $bind);
        return $multiWishlistId;
    }

    /**
     * @return array|bool
     */
    public function getExistStoreCodes()
    {
        if (empty($this->storeCodes)) {
            try {
                $select = $this->readAdapter->select()
                    ->from(
                        [$this->getTableName('store')],
                        ['store_id', 'code']
                    );

                $result = $this->readAdapter->query($select);
                foreach ($result as $value) {
                    if ($value['store_id'] != 0) {
                        $this->storeCodes[$value['store_id']] = $value['code'];
                    }
                }
            } catch (\Exception $e) {
                return false;
            }
        }
        return $this->storeCodes;
    }

    /**
     * @param string $sku
     * @return string
     */
    protected function getProductIdBySku($sku)
    {
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('catalog_product_entity')],
            ['entity_id']
        )->where(
            'main_table.sku = :sku'
        );
        $bind = [
            ':sku' => $sku,
        ];
        $productId = $this->readAdapter->fetchOne($select, $bind);
        return $productId;
    }

    /**
     * @param array $itemIds
     * @return void
     */
    public function deleteItems($itemIds)
    {
        $resource = $this->wishlistItemResource->create();
        $connection = $resource->getConnection();
        $connection->delete(
            $resource->getMainTable(),
            ['wishlist_item_id in (?)' => $itemIds]
        );
    }

    /**
     * @param string $rawQty
     * @return int
     */
    protected function getQty($rawQty)
    {
        if (is_numeric($rawQty) && $rawQty > 0) {
            $qty = (int) $rawQty;
        } else {
            $qty = 1;
        }
        return $qty;
    }

    /**
     * @param array $superAttribute
     * @return array
     */
    public function getConfigurableItemInfo($superAttribute)
    {
        $configurableInfo = [];
        if (is_array($superAttribute) || is_object($superAttribute)) {
            foreach ($superAttribute as $attributeId => $optionId) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('eav_attribute')],
                    ['attribute_code', 'attribute_id']
                )->join(
                    ['attribute_option' => $this->getTableName('eav_attribute_option')],
                    'main_table.attribute_id = attribute_option.attribute_id',
                    ['option_id']
                )->join(
                    ['option_value' => $this->getTableName('eav_attribute_option_value')],
                    'attribute_option.option_id = option_value.option_id',
                    ['value']
                )->where("main_table.attribute_id = :attributeId"
                )->where("attribute_option.option_id = :optionId");
                $bind = [
                    ':attributeId' => $attributeId,
                    ':optionId' => $optionId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $configurableInfo[] = strtolower($result['attribute_code'] . ":" . $result['value']);
            }
        }
        return $configurableInfo;
    }

    /**
     * @param array $superGroup
     * @return array
     */
    public function getGroupedInfo($superGroup)
    {
        $configurableInfo = [];
        if (is_array($superGroup) || is_object($superGroup)) {
            foreach ($superGroup as $childProductId => $qty) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('catalog_product_entity')],
                    ['sku']
                )->where("main_table.entity_id = :entityId");
                $bind = [
                    ':entityId' => $childProductId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $configurableInfo[] = strtolower($result['sku'] . ":" . $qty);
            }
        }
        return $configurableInfo;
    }

    /**
     * @param array $bundleOption
     * @param array $bundleOptionQty
     * @return array
     */
    public function getBundleInfo($bundleOption, $bundleOptionQty)
    {
        $bundleInfo = [];
        if (is_array($bundleOption) || is_object($bundleOption)) {
            foreach ($bundleOption as $bundleItemId => $itemId) {
                $select = $select = $this->readAdapter->select()->from(
                    ['main_table' => $this->getTableName('catalog_product_entity')],
                    ['sku']
                )->join(
                    ['bundle_selection' => $this->getTableName('catalog_product_bundle_selection')],
                    'main_table.entity_id = bundle_selection.product_id',
                    ['selection_id']
                )->where("bundle_selection.selection_id = :selectionId");
                $bind = [
                    ':selectionId' => $itemId,
                ];
                $result = $this->readAdapter->fetchRow($select, $bind);
                $bundleInfo[] = strtolower($result['sku'] . ":" . $bundleOptionQty[$bundleItemId]);
            }
        }
        return $bundleInfo;
    }

    public function getNoNameWishlistId($customerId, $wishlistName)
    {
        if (!empty($wishlistName)) {
            return false;
        }
        $select = $select = $this->readAdapter->select()->from(
            ['main_table' => $this->getTableName('wishlist')],
            ['wishlist_id']
        )->where(
            'main_table.customer_id = :customerId'
        )->where(
            'main_table.name is :name'
        );
        $bind = [
            ':customerId' => $customerId,
            ':name' => NULL
        ];

        return $this->readAdapter->fetchOne($select, $bind);
    }
}
