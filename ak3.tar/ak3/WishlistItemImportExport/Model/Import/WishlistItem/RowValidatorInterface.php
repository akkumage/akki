<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\WishlistItemImportExport\Model\Import\WishlistItem;

interface RowValidatorInterface extends \Magento\Framework\Validator\ValidatorInterface
{
    const ERROR_INVALID_CUSTOMER_EMAIL = 'errorInvalidCustomerEmail';

    const ERROR_PRODUCT_NOT_EXIST = 'errorProductNotExist';

    const ERROR_WRONG_CONFIGURABLE_FORMAT = 'errorWrongConfigurableFormat';

    const ERROR_WRONG_BUNDLE_FORMAT = 'errorWrongBundleFormat';

    const ERROR_WRONG_GROUPED_FORMAT = 'errorWrongGroupedFormat';

    const ERROR_EMPTY_WISHLIST_NAME = 'errorEmptyWishlistName';

    const ERROR_ROW_WAS_NOT_DELETED = 'errorRowWasNotDeleted';

    /**
     * Initialize validator
     *
     * @param \Magento\CatalogImportExport\Model\Import\Product $context
     * @return $this
     */
    public function init($context);
}
