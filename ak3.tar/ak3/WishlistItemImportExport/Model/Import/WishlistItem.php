<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\WishlistItemImportExport\Model\Import;

use Bss\WishlistItemImportExport\Model\Import\WishlistItem\RowValidatorInterface as ValidatorInterface;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingErrorAggregatorInterface;
use Magento\ImportExport\Model\Import;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingError;

class WishlistItem extends \Magento\ImportExport\Model\Import\Entity\AbstractEntity
{

    const COL_USER_EMAIL = 'user_email';

    const COL_PRODUCT_SKU = 'product_sku';

    const VALIDATOR_MAIN = 'validator';

    const DEFAULT_OPTION_VALUE_SEPARATOR = ';';

    /**
     * @var array
     */
    protected $_messageTemplates = [
        ValidatorInterface::ERROR_INVALID_CUSTOMER_EMAIL => 'Invalid Customer Email',
        ValidatorInterface::ERROR_PRODUCT_NOT_EXIST => 'Product is not exist',
        ValidatorInterface::ERROR_WRONG_BUNDLE_FORMAT => 'Wrong format of Bundle Product',
        ValidatorInterface::ERROR_WRONG_CONFIGURABLE_FORMAT => 'Wrong format of Configurable Product',
        ValidatorInterface::ERROR_WRONG_GROUPED_FORMAT => 'Wrong format of Grouped Product',
        ValidatorInterface::ERROR_EMPTY_WISHLIST_NAME => 'Empty Wishlist name',
        ValidatorInterface::ERROR_ROW_WAS_NOT_DELETED => 'Wrong infomation, cannot delete item'
    ];

    /**
     * @var bool
     */
    protected $needColumnCheck = true;

    /**
     * @var array
     */
    protected $swatchAttributes = [];

    /**
     * @var array
     */
    protected $validColumnNames = [
        'store_code',
        'added_at',
        self::COL_USER_EMAIL,
        'description',
        self::COL_PRODUCT_SKU,
        'product_qty',
        'configurable_product_info',
        'grouped_product_info',
        'bundle_product_info',
        'wishlist_name',
        'name'
    ];

    /**
     * @var bool
     */
    protected $logInHistory = true;

    /**
     * @var array
     */
    protected $_validators = [];

    /**
     * @var array
     */
    protected $_permanentAttributes = [self::COL_USER_EMAIL, self::COL_PRODUCT_SKU];

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $dateTime;

    /**
     * @var array
     */
    protected $tableNames = [];

    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $readAdapter;

    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $writeAdapter;

    /**
     * @var \Magento\Wishlist\Model\WishlistFactory
     */
    protected $wishlistFactory;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Wishlist\Model\ItemFactory
     */
    protected $wishlistItemFactory;

    /**
     * @var \Magento\Wishlist\Controller\WishlistProviderInterface
     */
    protected $wishlistProvider;

    /**
     * @var \Bss\WishlistItemImportExport\Model\ResourceModel\Import
     */
    protected $import;

    /**
     * @var WishlistItem\Validator\WishlistItem
     */
    protected $wishlistItemValidator;

    /**
     * @var \Magento\Wishlist\Model\ResourceModel\Item\Collection
     */
    protected $itemCollection;

    /**
     * @var \Magento\CatalogImportExport\Model\Import\Product
     */
    protected $importProductModel;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var array
     */
    protected $wishlistItemIds = [];

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $dataObject;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var \Magento\Wishlist\Model\ResourceModel\Wishlist\CollectionFactory
     */
    protected $wishlistColFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * WishlistItem constructor.
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\ImportExport\Helper\Data $importExportData
     * @param \Magento\ImportExport\Model\ResourceModel\Import\Data $importData
     * @param \Magento\Eav\Model\Config $config
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\ImportExport\Model\ResourceModel\Helper $resourceHelper
     * @param \Magento\Framework\Stdlib\StringUtils $string
     * @param ProcessingErrorAggregatorInterface $errorAggregator
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Wishlist\Model\WishlistFactory $wishlistFactory
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Wishlist\Model\ItemFactory $wishlistItemFactory
     * @param \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider
     * @param \Bss\WishlistItemImportExport\Model\ResourceModel\Import $import
     * @param WishlistItem\Validator\WishlistItem $wishlistItemValidator
     * @param \Magento\Wishlist\Model\ResourceModel\Item\CollectionFactory $itemCollection
     * @param \Magento\CatalogImportExport\Model\Import\Product $importProductModel
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\DataObjectFactory $dataObject
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Framework\App\ProductMetadataInterface $productMetadata
     * @param \Magento\Wishlist\Model\ResourceModel\Wishlist\CollectionFactory $wishlistColFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\MultipleWishlist\Helper\Data $helper
     */
    public function __construct(
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\ImportExport\Helper\Data $importExportData,
        \Magento\ImportExport\Model\ResourceModel\Import\Data $importData,
        \Magento\Eav\Model\Config $config,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\ImportExport\Model\ResourceModel\Helper $resourceHelper,
        \Magento\Framework\Stdlib\StringUtils $string,
        ProcessingErrorAggregatorInterface $errorAggregator,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Wishlist\Model\WishlistFactory $wishlistFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Wishlist\Model\ItemFactory $wishlistItemFactory,
        \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider,
        \Bss\WishlistItemImportExport\Model\ResourceModel\Import $import,
        \Bss\WishlistItemImportExport\Model\Import\WishlistItem\Validator\WishlistItem $wishlistItemValidator,
        \Magento\Wishlist\Model\ResourceModel\Item\CollectionFactory $itemCollection,
        \Magento\CatalogImportExport\Model\Import\Product $importProductModel,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\DataObjectFactory $dataObject,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Magento\Wishlist\Model\ResourceModel\Wishlist\CollectionFactory $wishlistColFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->dateTime = $dateTime;
        $this->jsonHelper = $jsonHelper;
        $this->_importExportData = $importExportData;
        $this->_resourceHelper = $resourceHelper;
        $this->_dataSourceModel = $importData;
        $this->_connection = $resource;
        $this->errorAggregator = $errorAggregator;
        $this->wishlistFactory = $wishlistFactory;
        $this->productRepository = $productRepository;
        $this->wishlistItemFactory = $wishlistItemFactory;
        $this->wishlistProvider = $wishlistProvider;
        $this->import = $import;
        $this->wishlistItemValidator = $wishlistItemValidator;
        $this->itemCollection = $itemCollection;
        $this->importProductModel = $importProductModel;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productFactory = $productFactory;
        $this->objectManager = $objectManager;
        $this->customerFactory = $customerFactory;
        $this->storeManager = $storeManager;
        $this->dataObject = $dataObject;
        $this->messageManager = $messageManager;
        $this->moduleManager = $moduleManager;
        $this->productMetadata = $productMetadata;
        $this->wishlistColFactory = $wishlistColFactory;
        $this->scopeConfig = $scopeConfig;

        $this->readAdapter = $this->_connection->getConnection('core_read');
        $this->writeAdapter = $this->_connection->getConnection('core_write');

        foreach (array_merge($this->errorMessageTemplates, $this->_messageTemplates) as $errorCode => $message) {
            $this->getErrorAggregator()->addErrorMessageTemplate($errorCode, $message);
        }
    }

    /**
     * @param $type
     * @return mixed
     */
    protected function _getValidator($type)
    {
        return $this->_validators[$type];
    }

    /**
     * @return string
     */
    public function getEntityTypeCode()
    {
        return 'bss_wishlist_item';
    }

    /**
     * @param array $rowData
     * @param int $rowNum
     * @return bool
     */
    public function validateRow(array $rowData, $rowNum)
    {
        $productCollection = $this->productCollectionFactory->create();
        $productIds = $productCollection->getAllIds();
        $productId = $this->productFactory->create()->getIdBySku($rowData['product_sku']);
        $customerId = $this->import->getExistCustomerId($rowData['user_email']);
        if (!in_array($productId, $productIds)) {
            $this->addRowError(ValidatorInterface::ERROR_PRODUCT_NOT_EXIST, $rowNum);
            return false;
        }

        if ($customerId === null) {
            $this->addRowError(ValidatorInterface::ERROR_INVALID_CUSTOMER_EMAIL, $rowNum);
            return false;
        }
        return true;
    }

    /**
     * @return bool
     */
    protected function _importData()
    {
        if (\Magento\ImportExport\Model\Import::BEHAVIOR_DELETE == $this->getBehavior()) {
            $this->deleteWishlistItem();
        } elseif (\Magento\ImportExport\Model\Import::BEHAVIOR_REPLACE == $this->getBehavior()) {
            $this->replaceWishlistItem();
        } elseif (\Magento\ImportExport\Model\Import::BEHAVIOR_APPEND == $this->getBehavior()) {
            $this->saveWishlistItem();
        }

        return true;
    }

    /**
     * Validate data rows and save bunches to DB.
     *
     * @return $this|Import\Entity\AbstractEntity
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\ValidatorException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    protected function _saveValidatedBunches()
    {
        $source = $this->_getSource();
        $currentDataSize = 0;
        $bunchRows = [];
        $startNewBunch = false;
        $nextRowBackup = [];
        $maxDataSize = $this->_resourceHelper->getMaxDataSize();
        $bunchSize = $this->_importExportData->getBunchSize();

        $source->rewind();
        $this->_dataSourceModel->cleanBunches();

        while ($source->valid() || $bunchRows) {
            if ($startNewBunch || !$source->valid()) {
                $this->_dataSourceModel->saveBunch($this->getEntityTypeCode(), $this->getBehavior(), $bunchRows);

                $bunchRows = $nextRowBackup;
                $currentDataSize = strlen(serialize($bunchRows));
                $startNewBunch = false;
                $nextRowBackup = [];
            }
            if ($source->valid()) {
                try {
                    $rowData = $source->current();
                } catch (\InvalidArgumentException $e) {
                    $this->addRowError($e->getMessage(), $this->_processedRowsCount);
                    $this->_processedRowsCount++;
                    $source->next();
                    continue;
                }

                $this->_processedRowsCount++;

                if ($this->validateRow($rowData, $source->key())) {
                    // add row to bunch for save
                    $rowData = $this->_prepareRowForDb($rowData);
                    $rowSize = strlen($this->jsonHelper->jsonEncode($rowData));

                    $isBunchSizeExceeded = $this->isBunchSize($bunchSize, $bunchRows);

                    if ($currentDataSize + $rowSize >= $maxDataSize || $isBunchSizeExceeded) {
                        $startNewBunch = true;
                        $nextRowBackup = [$source->key() => $rowData];
                    } else {
                        $bunchRows[$source->key()] = $rowData;
                        $currentDataSize += $rowSize;
                    }
                }
                $source->next();
            }
        }
        return $this;
    }

    /**
     * Check bunch size
     *
     * @param int $bunchSize
     * @param array $bunchRows
     * @return bool
     */
    protected function isBunchSize($bunchSize, $bunchRows)
    {
        return $bunchSize > 0 && count($bunchRows) >= $bunchSize;
    }

    /**
     * @return void
     */
    protected function saveWishlistItem()
    {
        while ($bunch = $this->_dataSourceModel->getNextBunch()) {
            foreach ($bunch as $rowNum => $rowData) {
                $this->processData($rowData);
            }
        }
    }

    /**
     * @param array $rowData
     * @return void
     */
    protected function processData($rowData)
    {
        try {
            $product = $this->productRepository->get($rowData['product_sku']);
            $customerId = $this->import->getExistCustomerId($rowData['user_email']);

            if ($this->isEnterprise()) {
                if ($this->scopeConfig->getValue(
                    'wishlist/general/multiple_enabled',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )) {
                    $noNameWishlistid = $this->import->getNoNameWishlistId($customerId, $rowData['wishlist_name']) === false ? null : $this->import->getNoNameWishlistId($customerId, $rowData['wishlist_name']);
                    $wishlist = $this->getEnterpriseWishlist($customerId, $rowData['wishlist_name'], 1, $noNameWishlistid);
                } else {
                    $wishlist = $this->wishlistFactory->create();
                    $wishlist->loadByCustomerId($customerId, true);
                }
            } else {
                $wishlist = $this->wishlistFactory->create();
                $wishlist->loadByCustomerId($customerId, true);
            }

            $superAttribute = $this->import->getConfigurableInfo(
                $rowData['configurable_product_info'],
                $this->getMultipleValueSeparator()
            );


            if (is_numeric($rowData['product_qty']) && $rowData['product_qty'] > 0) {
                $qty = (int)$rowData['product_qty'];
            } else {
                $qty = 1;
            }

            $data = [
                'product' => $product->getId(),
                'qty' => $qty,
            ];

            if (!empty($superAttribute)) {
                $data['super_attribute'] = $superAttribute;
            }

            $superGroup = $this->import->getGroupInfo(
                $rowData['grouped_product_info'],
                $this->getMultipleValueSeparator()
            );

            if (!empty($superGroup)) {
                $data['super_group'] = $superGroup;
            }

            $bundleOption = $this->import->getBundleOption(
                $rowData["bundle_product_info"],
                $this->getMultipleValueSeparator(),
                $product->getId()
            );

            $bundleQty = $this->import->getBundleQty(
                $rowData["bundle_product_info"],
                $this->getMultipleValueSeparator(),
                $product->getId()
            );

            if (!empty($bundleOption) && !empty($bundleQty)) {
                $data['bundle_option'] = $bundleOption;
                $data['bundle_option_qty'] = $bundleQty;
            }

            $buyRequest = $this->dataObject->create()->setData($data);

            $this->addToWishlist($rowData, $customerId, $wishlist, $product, $buyRequest, $qty);

            $wishlist->save();
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
    }

    /**
     * @param int $customerId
     * @param string $wishlistName
     * @param bool $visibility
     * @param null $wishlistId
     * @return \Magento\Framework\DataObject|\Magento\Wishlist\Model\Wishlist
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getEnterpriseWishlist($customerId, $wishlistName, $visibility = false, $wishlistId = null)
    {
        $wishlistHelper = $this->objectManager->create(\Magento\MultipleWishlist\Helper\Data::class);
        /** @var \Magento\Wishlist\Model\Wishlist $wishlist */
        $wishlist = $this->wishlistFactory->create();

        if ($wishlistId) {
            $wishlist->load($wishlistId);
        } else {

            /** @var \Magento\Wishlist\Model\ResourceModel\Wishlist\Collection $wishlistCollection */
            $wishlistCollection = $this->wishlistColFactory->create();
            $wishlistCollection->filterByCustomerId($customerId);
            $wishlistCollection->addFieldToFilter('name', $wishlistName);

            if ($wishlistCollection->getSize()) {
                return $wishlistCollection->getFirstItem();
            }

            $limit = $wishlistHelper->getWishlistLimit();
            if ($wishlistHelper->isWishlistLimitReached($wishlistCollection)) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Only %1 wish list(s) can be created.', $limit)
                );
            }

            $wishlist->setCustomerId($customerId);
            $wishlist->generateSharingCode();
        }

        $wishlist->setName($wishlistName)
            ->setVisibility($visibility)
            ->save();

        return $wishlist;
    }

    /**
     * @param array $rowData
     * @param int $customerId
     * @param \Magento\Wishlist\Model\Wishlist $wishlist
     * @param \Magento\Catalog\Model\Product $product
     * @param \Magento\Framework\DataObject $buyRequest
     * @param int $qty
     * @return void
     */
    protected function addToWishlist($rowData, $customerId, $wishlist, $product, $buyRequest, $qty)
    {
        if (!empty($rowData['wishlist_name'])) {
            if ($this->moduleManager->isEnabled('Bss_MultiWishlist')
            ) {
                $wishlistLabel = $this->objectManager->create(\Bss\MultiWishlist\Model\WishlistLabel::class);
                $wishlistLabelId = $this->import->checkExistedWishlistName($rowData['wishlist_name'], $customerId);
                if ($wishlistLabelId !== false) {
                    $wishlistLabel->load($wishlistLabelId);
                }
                $wishlistLabel->setCustomerId($customerId);
                $wishlistLabel->setWishlistName($rowData['wishlist_name']);
                $wishlistLabel->save();
                $wishlistItem = $wishlist->addNewItem(
                    $product,
                    $buyRequest,
                    false,
                    false,
                    $wishlistLabel->getId()
                );
            } else {
                $wishlistItem = $wishlist->addNewItem($product->getId(), $buyRequest);
            }
        } else {
            if ($this->moduleManager->isEnabled('Bss_MultiWishlist')
            ) {
                $wishlistItem = $wishlist->addNewItem($product, $buyRequest, false, false, 0);
            } else {
                $wishlistItem = $wishlist->addNewItem($product->getId(), $buyRequest);
            }
        }
        $customer = $this->customerFactory->create()->load($customerId);
        if (in_array($rowData['store_code'], $this->import->getExistStoreCodes())) {
            $storeId = $this->importProductModel->getStoreIdByCode($rowData['store_code']);
        } else {
            $storeId = $this->storeManager->getDefaultStoreView()->getId();
        }
        $wishlistItem->setStoreId($storeId);
        if (!empty($rowData['added_at'])) {
            $wishlistItem->setAddedAt($rowData['added_at']);
        } else {
            $wishlistItem->setAddedAt($customer->getData('created_at'));
        }
        $wishlistItem->setDescription($rowData['description']);
        $wishlistItem->setQty($qty);
    }


    /**
     * @return void
     */
    protected function replaceWishlistItem()
    {
        $this->deleteWishlistItem();
        $this->saveWishlistItem();
    }

    /**
     * @return $this
     */
    protected function deleteWishlistItem()
    {
        while ($bunch = $this->_dataSourceModel->getNextBunch()) {
            foreach ($bunch as $rowNum => $rowData) {
                $this->validateRow($rowData, $rowNum);
                if (!empty($rowData['bundle_product_info'])
                    || !empty($rowData['configurable_product_info'])
                    || !empty($rowData['grouped_product_info'])
                ) {
                    $this->deleteSpecialItems($rowNum, $rowData);
                } else {
                    $itemInfo = $this->import->getWishlistItem($rowData);
                    if (empty($itemInfo['wishlist_item_id'])) {
                        $this->addRowError(
                            ValidatorInterface::ERROR_ROW_WAS_NOT_DELETED,
                            $rowNum,
                            null,
                            null,
                            ProcessingError::ERROR_LEVEL_NOT_CRITICAL
                        );
                        continue;
                    }
                    $this->wishlistItemIds[] = $itemInfo['wishlist_item_id'];
                }

            }
        }
        $collection = $this->itemCollection->create();
        $collection->addFieldToFilter('wishlist_item_id', ['in' => $this->wishlistItemIds]);
        $this->import->deleteItems($this->wishlistItemIds);
        return $this;
    }

    /**
     * @param int $rowNum
     * @param array $rowData
     * @return void
     */
    protected function deleteSpecialItems($rowNum, $rowData)
    {
        $itemInfo = $this->import->getSpecialWishlistItems($rowData);
        $count = 0;
        foreach ($itemInfo as $item) {
            if ($this->deleteItem($item['wishlist_item_id'], $rowData) == true) {
                $count++;
            }
        }
        if ($count == 0) {
            $this->addRowError(
                ValidatorInterface::ERROR_ROW_WAS_NOT_DELETED,
                $rowNum,
                null,
                null,
                ProcessingError::ERROR_LEVEL_NOT_CRITICAL
            );
        }
    }

    /**
     * @param int $id
     * @param array $rowData
     * @return bool
     */
    protected function deleteItem($id, $rowData)
    {
        $wishlistItem = $this->wishlistItemFactory->create()->loadWithOptions($id);
        $buyRequest = $wishlistItem->getBuyRequest();

        $result = false;
        if (!empty($rowData['configurable_product_info'])) {
            $deleteInfo = explode(
                $this->getMultipleValueSeparator(),
                strtolower($rowData['configurable_product_info'])
            );
            $existInfo = $this->import->getConfigurableItemInfo($buyRequest['super_attribute']);
            if (empty(array_diff($deleteInfo, $existInfo))) {
                $wishlistItem->delete();
                $result = true;
            }
        }

        if (!empty($rowData['grouped_product_info'])) {
            $deleteInfo = explode(
                $this->getMultipleValueSeparator(),
                strtolower($rowData['grouped_product_info'])
            );
            $existInfo = $this->import->getGroupedInfo($buyRequest['super_group']);
            if (empty(array_diff($deleteInfo, $existInfo))) {
                $wishlistItem->delete();
                $result = true;
            }
        }

        if (!empty($rowData["bundle_product_info"])) {
            $deleteInfo = explode(
                $this->getMultipleValueSeparator(),
                strtolower($rowData['bundle_product_info'])
            );
            $existInfo = $this->import->getBundleInfo($buyRequest['bundle_option'], $buyRequest['bundle_option_qty']);
            if (empty(array_diff($deleteInfo, $existInfo))) {
                $wishlistItem->delete();
                $result = true;
            }
        }

        return $result;
    }

    /**
     * @return string
     */
    public function getMultipleValueSeparator()
    {
        if (!empty($this->_parameters[Import::FIELD_FIELD_MULTIPLE_VALUE_SEPARATOR])) {
            return $this->_parameters[Import::FIELD_FIELD_MULTIPLE_VALUE_SEPARATOR];
        }
        return Import::DEFAULT_GLOBAL_MULTI_VALUE_SEPARATOR;
    }

    /**
     * @return bool
     */
    protected function isEnterprise()
    {
        if ($this->productMetadata->getEdition() == "Enterprise") {
            return true;
        }
        return false;
    }
}
