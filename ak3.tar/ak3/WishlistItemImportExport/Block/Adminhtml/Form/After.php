<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\WishlistItemImportExport\Block\Adminhtml\Form;

class After extends \Magento\ImportExport\Block\Adminhtml\Form\After
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Customer\Model\ResourceModel\Group\Collection
     */
    protected $customerGroupCollection;

    /**
     * After constructor.
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Customer\Model\ResourceModel\Group\Collection $customerGroupCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\ResourceModel\Group\Collection $customerGroupCollection,
        array $data = []
    ) {
        $this->storeManager = $context->getStoreManager();
        $this->customerGroupCollection = $customerGroupCollection;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return \Magento\Store\Api\Data\StoreInterface[]
     */
    public function getAllStores()
    {
        return $this->storeManager->getStores();
    }

    /**
     * @return array
     */
    public function getCustomerGroups()
    {
        $customerGroups = $this->customerGroupCollection->toOptionArray();
        unset($customerGroups[0]);
        return $customerGroups;
    }
}
