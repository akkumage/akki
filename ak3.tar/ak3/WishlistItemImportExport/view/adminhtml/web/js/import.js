/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
define([
    "jquery"
], function ($) {
    "use strict";
    $('#entity').change(function () {
        if ($('#entity').val()=='bss_wishlist_item') {
            $('#basic_behavior_import_multiple_value_separator').val('|');
            $('.field-basic_behaviorfields_enclosure').hide();
            $('.field-basic_behavior__import_field_separator').hide();
            $('.field-import_images_file_dir').hide();
            $('#bss-version').show();
            $('#bss-version').appendTo('.field-entity .admin__field-control.control .admin__field');
        } else {
            $('#bss-version').hide();
            $('#basic_behavior_import_multiple_value_separator').val(',');
        }
    });
});
