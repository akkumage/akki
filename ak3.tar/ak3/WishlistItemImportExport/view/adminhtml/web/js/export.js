/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_WishlistItemImportExport
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
require([
    'jquery',
    'prototype'
], function ($) {
    $("#entity").change(function () {
        $('#export_filter_container').show();
    });

    $("#export-by").change(function () {
        switch ($('#export-by').val()) {
            case 'customer-email':
                $('#customer-email').show();
                $('#product-sku').hide();
                $('#customer-group').hide();
                break;
            case 'product-sku':
                $('#customer-email').hide();
                $('#product-sku').show();
                $('#customer-group').hide();
                break;
            case 'customer-group':
                $('#customer-email').hide();
                $('#product-sku').hide();
                $('#customer-group').show();
                break;
            default:
                $('#customer-email').hide();
                $('#product-sku').hide();
                $('#customer-group').hide();
        }
    });

    $('entity').selectedIndex = 0;
});