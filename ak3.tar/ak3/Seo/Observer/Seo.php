<?php
namespace Vajor\Seo\Observer;

class Seo implements \Magento\Framework\Event\ObserverInterface
{

	   	private $logger;

		public function __construct(\Psr\Log\LoggerInterface $logger){
		    $this->logger = $logger;	   
		
		}

	 	public function execute(\Magento\Framework\Event\Observer $observer){

			 /** @type \Magento\Catalog\Model\Product $product */
			 $product = $observer->getProduct();				 
			try{

				 $product_status = $product->getStatus(); 			
				 $_getMetatag_value = $product->getMpMetaRobots();


				if ($product_status == 2 && $_getMetatag_value == "INDEX,FOLLOW"){                /*Disable Product*/
							$product->setMpMetaRobots("NOINDEX,NOFOLLOW");
					        $product->save();
					        /*$_getMetatag_value = $product->getMpMetaRobots();*/
					
				}if ($product_status == 1 && $_getMetatag_value =="NOINDEX,NOFOLLOW"){				/*Enable Product*/
					        $product->setMpMetaRobots("INDEX,FOLLOW");
					        $product->save();
					
				}

			}catch (\Exception $e){
		        	$this->logger->critical($e->getMessage());
		    }

	  }

  }


?>
