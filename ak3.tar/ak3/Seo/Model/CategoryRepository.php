<?php    
namespace Vajor\Seo\Model;


class CategoryRepository 
{

 public function afterSave(\Magento\Catalog\Model\CategoryRepository $subject,$result)
    {
        /*print_r($result->getData());
        echo $categoryId = $result->getId(); //get category id 
        die("rerer");*/
    }
}