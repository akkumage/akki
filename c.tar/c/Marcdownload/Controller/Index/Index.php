<?php
namespace OM\Marcdownload\Controller\Index;
use \OM\Marcdownload\Helper\Data;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory; 



require_once('lib/File_MARC-1.1.1/File/MARC.php');
class Index extends \Magento\Framework\App\Action\Action
{
  private $wishlist;
  private $helper;
  protected $_productloader; 
  protected $filesystem;
  protected $orderRepository;
protected $_messageManager;

  public function __construct(\Magento\Framework\App\Action\Context $context,
  								\Magento\Wishlist\Model\Wishlist $wishlist,
  								 \Magento\Catalog\Model\ProductFactory $_productloader,
  								 Data $helper,
  								  \Magento\Framework\Filesystem $filesystem,
  								   \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
  								   \Magento\Framework\Message\ManagerInterface $messageManager
  							)
  {
  	 $this->helper = $helper;
  	$this->wishlist = $wishlist;
  	$this->_productloader = $_productloader;
  	$this->orderRepository = $orderRepository;
  	$this->_filesystem = $filesystem;
  	 $this->_messageManager = $messageManager;
    return parent::__construct($context);
  }
 
  public function execute()
  {
  	$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
  	$wishlist_id=$this->getRequest()->getParam('wishlist_id');
  	$order_id=$this->getRequest()->getParam('order_id');
  	if($wishlist_id || $order_id){
  		$mediapath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
// var_dump($mediapath);die();
        $file = fopen($mediapath.'marc/marc_edit_record_'. $wishlist_id .'.mrc', 'w');
        if($wishlist_id){
        	$itemCollection = $this->wishlist->load($wishlist_id)->getItemCollection();
        }
        if($order_id){
        	$order = $this->orderRepository->get($order_id);
        	$itemCollection=$order->getAllVisibleItems();
        }
        foreach($itemCollection as $item) {
        	$product=$this->_productloader->create()->load($item->getProductId());
            $title = $product->getName();
            // var_dump($product->getData());die();
            $year = $product->getYear();
            $media = $product->getMedia();
            $barcode = $product->getBarcode();
            $artist =$product->getArtist();

          //   if(!$title || !$year || !$media ||!$barcode || !$artist){
          //   	 var_dump($title ,$year,$media,$barcode,$artist);die();
          //   	$this->_messageManager->addError(__("Product details is missing"));
          //   	$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        		// return $resultRedirect;
          //   }
            $marc = new \File_MARC_Record();
            $marc = $this->helper->createLeader($marc, $media);
            $marc = $this->create007Record($marc, $media);
            $marc = $this->create008Record($marc, $year, $media);
            $token = 0;
            if($media == 'Manga' || $media == 'Paperback' || $media == 'GRAPHIC NOVEL' || $media == 'Hardcover' || $media == 'BOOK') {
                $token = 1;
            }    

            if($token == 1) {
                $marc = $this->create020Record($marc, $barcode);
            }
            else {
                $marc = $this->create024Record($marc, $barcode);
            }

            $marc = $this->create040Record($marc);
            if($token == 1 || $media == '$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;CD') {
                if(trim($artist) != NULL)
                    $marc = $this->create100Record($marc, $artist, $year);
            }
            
            $marc = $this->create245Record($marc, $media, $title, $artist);
            $marc = $this->create264Record($marc, $year);
            fwrite($file, $marc->toRaw());
        }

        fclose($file);
        $filename = $mediapath.'marc/marc_edit_record_'. $wishlist_id .'.mrc';
        header('Content-Type: application/octet-stream');
        header("Content-Transfer-Encoding: Binary"); 
        header("Content-disposition: attachment; filename=\"" . basename($filename) . "\""); 
        readfile($filename);
        exit;
  	}else{
  		$this->_messageManager->addError(__("Something is wrong. please try again later"));
  		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
  	}
  }
   public function create007Record($marc, $media)
    {
        if($media == 'DVD') {
            $code1 = 'v';
            $code2 = 'd';
            $value = '\cvaizu';
        }
        elseif($media == 'Blu-Ray' || $media == 'blu-ray' || $media == 'BLURAY') {
            $code1 = 'v';
            $code2 = 'd';
            $value = '\csaizq';
        }
        elseif($media == 'Manga' || $media == 'Paperback' || $media == 'GRAPHIC NOVEL' || $media == 'Hardcover' || $media == 'BOOK') {
            $code1 = '';
            $code2 = '';
            $value = '';
        }
        elseif($media == 'CDrom' || $media == 'cd-rom' || $media == 'CD-rom' || $media == 'CDROM') {
            $code1 = 'c';
            $code2 = 'o';
            $value = '|cga' . '||||||||';
        }
        elseif($media == 'CD') {
            $code1 = 's';
            $code2 = 'd';
            $value = '|fsngnnmmned';
        }
        elseif($media == 'Playstation 3' || $media == 'Playstation 4' || $media == 'Playstation Vita' || $media == 'Nintendo 3DS' || $media == 'Xbox 360' || $media == 'Xbox One' || $media == 'Nintendo Wii' || $media == 'Nintendo Wii U') {
            $code1 = 'c';
            $code2 = 'o';
            $value = '|cga' . '||||||||';
        }
    
        $subfield = new \File_MARC_Subfield('', $value);
        // var_dump($subfield);
        // var_dump((object)$subfield);die();
        $field = new \File_MARC_Data_Field('007',
                (object)$subfield,  		
             null, null
        );
        

        $field->setIndicator(1, $code1);
        $field->setIndicator(2, $code2) ;

        // dynamic value as per category switch
        $marc->appendField($field);

        return $marc;
    }

    public function create008Record($marc, $year, $media)
    {
        $todayYear = str_split(date("y")); //date in yymmdd format
        $todayDate = date("md"); //date in yymmdd format
        if(trim($year) == '' || $year == null) 
            $year = '||||';
        // current date + s + year of movie  + static string eg: '=008  140514s2014\\\\at\---\|\\\\\||\\\||und|d
        if($media == 'DVD') {
            $str008 = "||||at\---|\\\\\\\\\\\\\\\\\\\\\\v|und\d";
            $str = $todayDate . 's' . $year . $str008;
        }
        elseif($media == 'Blu-Ray' || $media == 'blu-ray' || $media == 'BLURAY') {
            //$str008 = "\\\\\\\at\---\|\\\\\\\\\\\\\\\\\\\\v|und\d";
            $str008 = "||||at\---|\\\\\\\\\\\\\\\\\\\\\\v|und\d";
            $str = $todayDate . 's' . $year . $str008;
        }
        elseif($media == 'Manga' || $media == 'Paperback' || $media == 'GRAPHIC NOVEL' || $media == 'Hardcover' || $media == 'BOOK') {
            $str008 = "\\\\\\\\at\\\\\\\\\d\\\\\\\\\\\\000\\0\\eng\d";
            $str = $todayDate . 's' . $year . $str008;
        }
        elseif($media == 'CDrom' || $media == 'cd-rom' || $media == 'CD-rom' || $media == 'CDROM') {
            $str008 = "\\\\\\\at\\\\\\\\\\g\\\\\|\\\\\\\\\\\\\\\\und\d";
            $str = $todayDate . 's' . $year . $str008;
        }
        elseif($media == 'CD') {
            $str008 = "||||at\||||\\\\\\\\\\\\\\\\\\\\\\\\|und\d";
            $str = $todayDate . 's' . $year . $str008;
        }
        elseif($media == 'Playstation 3' || $media == 'Playstation 4' || $media == 'Playstation Vita' || $media == 'Nintendo 3DS' || $media == 'Xbox 360' || $media == 'Xbox One' || $media == 'Nintendo Wii' || $media == 'Nintendo Wii U') {
            $str008 = "||||at\\|\\\\\\eq\\\\\\\\\\\\\\\\\\\\\und\d";
            $str = $todayDate . 's' . $year . $str008;
        }

        $field = new \File_MARC_Data_Field('008', array(
                new \File_MARC_Subfield('', $str),
            ), null, null
        );

        $field->setIndicator(1, $todayYear[0]);
        $field->setIndicator(2, $todayYear[1]);
        $marc->appendField($field);

        return $marc;
    }

    public function create024Record($marc, $barcode)
    {
        //append '3\' in front of $a$barcode eg: '=024  3\$a9321337152240
//   $test = yaz_record($marc, 1, "raw");

    $temp = "\x1F";
    $field = new \File_MARC_Data_Field('024', 
                new \File_MARC_Subfield($temp . 'a', $barcode),
        null, null
            );

     $field->setIndicator(1,'3');
      $marc->appendField($field);

        return $marc;

    }

    public function create020Record($marc, $barcode)
    {
        //append '3\' in front of $a$barcode eg: '=024  3\$a9321337152240
        //   $test = yaz_record($marc, 1, "raw");

        $temp = "\x1F";
        $field = new \File_MARC_Data_Field('020', 
                    new \File_MARC_Subfield($temp . 'a', $barcode),
                    null, null
                );

        $marc->appendField($field);
        return $marc;

    }

    public function create100Record($marc, $artist, $year) {
        $temp = "\x1F";

        $field = new \File_MARC_Data_Field('100', 
                        new \File_MARC_Subfield($temp . 'a', $artist),
                        null, null
                    );

        $field->setIndicator(1,'1');
        $marc->appendField($field);
        return $marc;
    }

    public function create040Record($marc)
    {
        // before the 2 fields eg: =040  \\$aVDES$cVDES
         $temp = "\x1F";
         $marc->appendField(new \File_MARC_Data_Field('040', array(
                new \File_MARC_Subfield($temp . 'a', 'VDES'),
                new \File_MARC_Subfield($temp . 'c', 'VDES'),
            ), null, null
        ));

         return $marc;
    }

    public function create245Record($marc, $media, $title, $artist)
    {
        // title , media eg: =245  00$aEnough Said$h[videorecording]
        $temp = "\x1F";
        if($media == 'DVD') {
            $mediaConstant = 'videorecording';
        }
        elseif($media == 'Blu-Ray' || $media == 'blu-ray' || $media == 'BLURAY') {
            $mediaConstant = 'blu-ray';
        }
        elseif($media == 'Manga' || $media == 'Paperback' || $media == 'GRAPHIC NOVEL' || $media == 'Hardcover' || $media == 'BOOK') {
            $mediaConstant = $artist;
            $extra = '/';
        }
        elseif($media == 'CDrom' || $media == 'cd-rom' || $media == 'CD-rom' || $media == 'CDROM') {
            $mediaConstant = 'cd-rom';
        }
        elseif($media == 'CD') {
            $mediaConstant = 'sound recording';
            $extra = '/';
        }
        elseif($media == 'Playstation 3' || $media == 'Playstation 4' || $media == 'Playstation Vita' || $media == 'Nintendo 3DS' || $media == 'Xbox 360' || $media == 'Xbox One' || $media == 'Nintendo Wii' || $media == 'Nintendo Wii U') {
            $mediaConstant = 'electronic resource';
        }

        if($mediaConstant != '' && $media == 'CD' && $artist != '' && $artist != NULL)
            $formatmedia = '[' . $mediaConstant . '] ' ;
        else 
            $formatmedia = '[' . $mediaConstant . '].' ;

        if($media == 'Manga' || $media == 'Paperback' || $media == 'Hardcover') {
            $firstSubfield = new \File_MARC_Subfield($temp . 'a', $title . ' ');
            $condSubfield = new \File_MARC_Subfield($extra .$temp . 'c', $mediaConstant);
        }
        else {
            $firstSubfield = new \File_MARC_Subfield($temp . 'a', $title);
            $condSubfield = new \File_MARC_Subfield($temp . 'h', $formatmedia);
        }
        
            
        if($media == 'CD' && ($artist != '' || $artist != NULL)) {
            $field = new \File_MARC_Data_Field('245', array(
                    $firstSubfield,
                    $condSubfield,
                    new \File_MARC_Subfield($extra .$temp . 'c', $artist),
                ), null, null
            );
        }
        else {
            $field = new \File_MARC_Data_Field('245', array(
                    $firstSubfield,
                    $condSubfield
                ), null, null
            );
        }
        

        $field->setIndicator(1, '1');
        $field->setIndicator(2, '0');
        $marc->appendField($field);
        return $marc;
    }

    public function create264Record($marc, $year)
    {
        //  year of movie eg: 
        if(trim($year) == '' || $year == null) 
            $year = '20??';

        $temp = "\x1F";
        $year = '[' . $year . ']';
        $field = new \File_MARC_Data_Field('264', array(
                new \File_MARC_Subfield($temp . 'c', $year)
            ), null, null
        );

        $field->setIndicator(1,'2');
        $marc->appendField($field);
        return $marc;
    }
}
