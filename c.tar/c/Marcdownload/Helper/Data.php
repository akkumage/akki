<?php
namespace OM\Marcdownload\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    public function createLeader($marc,$media)
    {
        if($media == 'DVD') {
            $marcLeader = 'ngm';
        }
        elseif($media == 'Blu-Ray' || $media == 'blu-ray' || $media == 'BLURAY') {
            $marcLeader = 'cgm';
        }
        elseif($media == 'Manga' || $media == 'Paperback' || $media == 'GRAPHIC NOVEL' || $media == 'Hardcover' || $media == 'BOOK') {
            $marcLeader = 'cam';
        }
        elseif($media == 'CDrom' || $media == 'cd-rom' || $media == 'CD-rom' || $media == 'CDROM') {
            $marcLeader = 'cmm';
        }
        elseif($media == 'CD') {
            $marcLeader = 'cjm';
        }
        elseif($media == 'Playstation 3' || $media == 'Playstation 4' || $media == 'Playstation Vita' || $media == 'Nintendo 3DS' || $media == 'Xbox 360' || $media == 'Xbox One' || $media == 'Nintendo Wii' || $media == 'Nintendo Wii U') {
            $marcLeader = 'cmm';
        }
        
        // Switch case DVD - ngm , Blu ray - ngm , Manga - nam, CD Rom - nmm, CD - njm
        $marc->setLeader(substr_replace($marc->getLeader(), $marcLeader, 5, 3));
        if($media == 'Manga' || $media == 'Paperback' || $media == 'Hardcover' || $media == 'CD')
            $marc->setLeader(substr_replace($marc->getLeader(), 'a', 10, 1));
        $marc->setLeader(substr_replace($marc->getLeader(), ' a', 17, 1));
        return $marc;
    }

   
}