<?php

    namespace Vajor\Gst\Observer;

    use Magento\Framework\Event\ObserverInterface;
    use Magento\Framework\App\RequestInterface;

    class Gst implements ObserverInterface
    {
        public function execute(\Magento\Framework\Event\Observer $observer)
        {
            $orderids = $observer->getEvent()->getOrderIds();
            foreach($orderids as $orderid){
				
				// getting actual order id
				$order_entity_id = $orderid;
			}
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$order = $objectManager->create('\Magento\Sales\Model\Order')->load($order_entity_id);
			
			// getting order increment id
			$increment_id = $order->getIncrementId();
			
			// getting all items from order
			$orderItems = $order->getAllItems();
			
			// getting shipping region id from order
			$shipping_region_id = $order->getShippingAddress()->getRegionId();
			
			// getting tax amount from order
			$order_total_gst = $order->getTaxAmount();
			$order_total_igst = 0;
			$order_total_cgst = 0;
			$order_total_sgst = 0;
			
			// getting connection to database
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			
			// setting table name to store itemwise gst data
			$tableName = $resource->getTableName('sales_order_item_gst');
			
			foreach ($orderItems as $item) {
				$item_id = $item->getId();
				$item_sku = $item->getSku();
				$product = $item->getProduct();
				$item_name = $product->getName();
				$item_total_gst_amount = $item->getTaxAmount();
				$item_total_gst_percent = $item->getTaxPercent();
				if($shipping_region_id = 497)
				{
					$item_cgst_value = $item_total_gst_amount/2;
					$order_total_cgst += $item_cgst_value;
					$item_cgst_percentage = $item_total_gst_percent/2;
					$item_sgst_value = $item_total_gst_amount/2;
					$order_total_sgst += $item_sgst_value;
					$item_sgst_percentage = $item_total_gst_percent/2;
					$item_igst_value = '';
					$item_igst_percentage = '';
				}
				else
				{
					$item_cgst_value = '';
					$item_cgst_percentage = '';
					$item_sgst_value = '';
					$item_sgst_percentage = '';
					$item_igst_value = $item_total_gst_amount;
					$order_total_igst += $item_igst_value;
					$item_igst_percentage = $item_total_gst_percent;
				}
				
				// Query to insert gst data itemwise
				$sql = "INSERT INTO " . $tableName . " (entity_id, order_id, increment_id, item_id, item_sku, item_name, item_cgst_value, item_cgst_percentage, item_sgst_value, item_sgst_percentage, item_igst_value, item_igst_percentage, item_total_gst_value, item_total_gst_percentage) VALUES ('', '$order_entity_id', '$increment_id', '$item_id', '$item_sku', '$item_name', '$item_cgst_value', '$item_cgst_percentage', '$item_sgst_value', '$item_sgst_percentage', '$item_igst_value', '$item_igst_percentage', '$item_total_gst_amount', '$item_total_gst_percent')";
				
				$connection->query($sql);
			}
			
			// getting selected payment method
			$payment = $order->getPayment();
			$method = $payment->getMethodInstance();
			$payment_method = $method->getCode();
			
			//getting shipping amount
			$shipping_amount = $order->getShippingAmount();
			if($payment_method == 'msp_cashondelivery')
			{
				$order_total_gst += 11.70;
				if($shipping_region_id = 497)
				{
					$order_total_cgst += 5.85;
					$order_total_sgst += 5.85;
				}
				else
				{
					$order_total_igst += 11.70;
				}
			}
			if($shipping_amount > 0)
			{
				$order_total_gst += 14.40;
				if($shipping_region_id = 497)
				{
					$order_total_cgst += 7.20;
					$order_total_sgst += 7.20;
				}
				else
				{
					$order_total_igst += 14.40;
				}
			}
			
			// setting table name to store orderwise gst data
			$tableName = $resource->getTableName('sales_order_gst');
			
			// Query to insert gst data orderwise
			$sql = "INSERT INTO " . $tableName . " (entity_id, order_id, increment_id, igst_total, cgst_total, sgst_total, gst_total) VALUES ('', '$order_entity_id', '$increment_id', '$order_total_igst', '$order_total_cgst', '$order_total_sgst', '$order_total_gst')";
			
			$connection->query($sql);
			
        }
    }
