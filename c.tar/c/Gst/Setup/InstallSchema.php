<?php

namespace Vajor\Gst\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.0') < 0){

		$installer->run('create table sales_order_item_gst(entity_id int(20) not null auto_increment, order_id int(20) not null, increment_id int(20) not null, item_id int(20) not null, item_sku varchar(255) not null, item_name varchar(255) not null, item_cgst_value decimal(12,4), item_cgst_percentage decimal(12,4), item_sgst_value decimal(12,4), item_sgst_percentage decimal(12,4), item_igst_value decimal(12,4), item_igst_percentage decimal(12,4), item_total_gst_value decimal(12,4), item_total_gst_percentage decimal(12,4), primary key(entity_id))');

		$installer->run('create table sales_order_gst(entity_id int(20) not null auto_increment, order_id int(20) not null, increment_id int(20) not null, igst_total decimal(12,4), cgst_total decimal(12,4), sgst_total decimal(12,4), gst_total decimal(12,4), primary key(entity_id))');
		}

        $installer->endSetup();

    }
}
