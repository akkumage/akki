<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
class Freeshipping{

protected $_checkoutSession;        

protected $_scopeConfig;

protected $_customerSession;

public function __construct(
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    \Magento\Store\Model\StoreManagerInterface $storeManager,
    \Magento\Customer\Model\Session $customerSession
) {
    $this->_storeManager = $storeManager;
    $this->_checkoutSession = $checkoutSession;
    $this->_scopeConfig = $scopeConfig;
    $this->_customerSession = $customerSession;
}

public function afterCollectRates(\Magento\OfflineShipping\Model\Carrier\Freeshipping $Freeshipping, $result)
{   
    //Magento-2 Log Here
    $writer = new \Zend\Log\Writer\Stream(BP.'/var/log/magento2freeshipping.log');
    $logger = new \Zend\Log\Logger();
    $logger->addWriter($writer);     
    $logger->info("Freeshipping shipping has been calling");                
    //keep your condition if you want

    return false;       

    return $result;
}  

}
