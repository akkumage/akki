<?php
namespace OM\CustomForm\Controller\Index;
 
use Zend\Log\Filter\Timestamp;
 
class Index extends \Magento\Framework\App\Action\Action
{
    const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_general/name';
    const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_general/email';
       
    protected $_inlineTranslation;
    protected $_transportBuilder;
    protected $_scopeConfig;
    protected $_logLoggerInterface;
    protected $_storeManager;
     
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
         
        )
    {
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;
        $this->_storeManager = $storeManager;

        $this->messageManager = $context->getMessageManager();
         
         
        parent::__construct($context);
         
         
    }
     
    protected function getConfigValue($path, $storeId)
    {
        return $this->_scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
 
    /**
     * Return store 
     *
     * @return Store
     */
    public function getStore()
    {
        return $this->_storeManager->getStore();
    }


    public function execute()
    {
        $post = $this->getRequest()->getPost();
        
        if(!empty($post) && \Zend_Validate::is(trim($post['email']), 'EmailAddress') && !empty($post['event_source'])){
                
                $event_source = ['Earth Bowl Recipes','Nature Retreat in Binsar','Zero Waste Living','Coffee & Calligraphy Date','Macrame Workshop','Life At Mimansa','Parenting The Millennials','Clayful Date','Enchanting Jungle Lore'];
                
                if(!in_array($post['event_source'],$event_source)){
                    $this->messageManager->addError('There is some error accured while submiting, please try again later.');
                    $this->_redirect('experiences');
                }

                try
                {
                    // Send Mail
                    $this->_inlineTranslation->suspend();
                                        
                    $sender = [
                        'email'     => 'info@vajor.com',
                        'name'      => $this->getConfigValue(self::XML_PATH_EMAIL_RECIPIENT_NAME,$this->_storeManager->getStore()->getId())
                    ];
                     
                    $sentToEmail    = 'experiences@vajor.com';
                    $sentToName     = 'Vajor.com';
                    $vars = [
                            'name'      => $post['name'],
                            'email'     => $post['email'],
                            'mobile'    => $post['mobile'],
                            'people'    => (int)$post['people'],
                            'event_source' => $post['event_source']
                    ];

                    /* send mail to admin user */

                    $transport = $this->_transportBuilder
                    ->setTemplateIdentifier('customemail_email_template')
                    ->setTemplateOptions(
                         [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 
                         'store' => $this->_storeManager->getStore()->getId(),
                        ]
                        )
                        ->setTemplateVars($vars)
                        ->setFrom($sender)
                        ->addTo($sentToEmail,$sentToName)
                        ->getTransport();
                         
                        $transport->sendMessage();
                        
                        /* send mail to user */

                        $transport = $this->_transportBuilder
                        ->setTemplateIdentifier('thankyou_email_template')
                        ->setTemplateOptions(
                         [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 
                         'store' => $this->_storeManager->getStore()->getId(),
                        ]
                        )
                        ->setTemplateVars($vars)
                        ->setFrom($sender)
                        ->addTo($post['email'],$post['name'])
                        ->getTransport();
                         
                        $transport->sendMessage();

                        $this->_inlineTranslation->resume();

                        $this->messageManager->addSuccess('Your request has been send successfully. We will contact you soon. Thanks you!!');


                        $this->_redirect('experiences');
                         
                } catch(\Exception $e){                 
                    echo $e->getMessage();
                    $this->messageManager->addError($e->getMessage());
                    $this->_logLoggerInterface->debug($e->getMessage());                    
                }
                 
        }else {
            $this->messageManager->addError('There is some error accured while submiting, please try again later.');

            $this->_redirect('experiences');
        }
         
    }
}